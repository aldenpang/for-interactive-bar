#ifndef _ET99LICDLL_H
#define _ET99LICDLL_H

#ifdef __cplusplus
extern "C" {
#endif

long _stdcall ET99App_SetLicense
(
    char* pcPID,
	char* pcUserPIN,
	int iIndex,
	char* pcLicense
);

long _stdcall ET99App_CheckLicense
(
	char* pcPID,
	char* pcUserPIN,
	int iIndex,
	char* pcLicense
);

long _stdcall ET99App_Set3DESKey
(
    char* pcPID,
	char* pcUserPIN,
	char* pc3DESKey
);

long _stdcall ET99App_3DESEnc
(
	char* pcPID,
	char* pcUserPIN,
	char* pcIV,
	char* pcData,
	int iDataLen
);

long _stdcall ET99App_3DESDec
(
	char* pcPID,
	char* pcUserPIN,
	char* pcIV,
	char* pcData,
	int iDataLen
);

#ifdef __cplusplus
}
#endif

#endif