#pragma hdrstop

//---------------------------------------------------------------------------

#pragma argsused
/*====================================================================
	Copyright (C) Rockey Tech. Co. Ltd. All rights reserved.

	File: 	ET299Edit.cpp

	Purpose:Sample console editor for ET299
======================================================================*/
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include "ET_API.h"
#pragma link "ET_BCB.lib"
ET_HANDLE g_hToken = NULL;

int WaitForUserInput()
{
	int  ic;
	//
	printf("\nInput selection:");
	fflush(stdin);
	//
	ic = getchar();
	//
	fflush(stdin);
	return ic;
}

void ShowMainCmdMenu()
{
	//HANDLE hStd=GetStdHandle(STD_OUTPUT_HANDLE); 
	//SetConsoleTextAttribute(hStd,FOREGROUND_INTENSITY|FOREGROUND_BLUE|FOREGROUND_GREEN);
	
	printf("\n\nMain menu:\n");
	printf("-------------------------------------------------------------\n");
	printf(	"  [F]ind      Open[T]oken    LED[O]n          D[A]taMenu\n"
			"  GetS[N]     GenP[I]D       GenRando[M]      Cr[Y]ptMenu\n"
			"  User[P]IN   [S]OPIN        [R]eset          Set[U]pMenu\n"
			"  LE[D]Off    [C]lose        ET29[9]          Update[L]icense\n"
			"  [E]T99 Time E[X]it\n"
			);
	//SetConsoleTextAttribute(hStd,FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_RED);	
}

void ShowBanner()
{
	printf("\nRockey ET299 Editor v1.0.\nCreate at " __DATE__ ", " __TIME__ "\n\n" );

	printf( "Library version is V1.0\n");
}

void ShowErrInfo(ET_STATUS retval)
{
	switch(retval)
	{
	case ET_SUCCESS				    	 :
		printf("Success!\n");
		return;
	case ET_ACCESS_DENY					 :
		printf("Err: access denied, have not enough right!");
		break;
	case ET_COMMUNICATIONS_ERROR		 :
		printf("Err: have not open the device");
		break;
	case ET_INVALID_PARAMETER		     :
		printf("Err: invalid parameter!");
		break;
	case ET_NOT_SET_PID					 :
		printf("Err: have not set PID!");
		break;
	case ET_UNIT_NOT_FOUND			     :
		printf("Err: open the device fail!");
		break;
	case 0xF0                            :
		printf("Err: PIN have been locked!");
		break;
	default								 :
		{
			if(retval&0xF0)
				printf("Err: PIN is wrong!");
			else
				printf("Err: unknown error occured!");
		}
		break;
	}
	printf("(0x%X)\n",retval);
}

void ShowBinHex(unsigned char* pBin, long len)
{
	// Show 16 bytes each line.
	int  i, j ,k, kk;
	long lLines = len / 16;
	long lCharInLastLine = 0;
	if(0 != len % 16)
	{
		lCharInLastLine = len - lLines * 16;
	}

	for(i = 0; i < lLines; ++i)
	{
		for(j = 0; j < 16; ++j)
		{
			printf("%02X ", pBin[16 * i + j]);

			if(j == 7)
				printf("- ");
		}

		printf("    ");

		for(j = 0; j < 16; ++j)
		{
			if(isprint(pBin[16 * i + j]))
				printf("%c", pBin[16 * i + j]);
			else
				printf(".");
		}

		printf("\n");
	}

	if(0 != lCharInLastLine)
	{
		for(j = 0; j < lCharInLastLine; ++j)
		{
			printf("%02X ", pBin[16 * i + j]);

			if(j == 7 && lCharInLastLine > 8)
				printf("- ");
		}

		k = 0;

		k += ((16 - lCharInLastLine) * 3);

		if(lCharInLastLine <= 8)
		{
			k += 2;
		}

		for(kk = 0; kk < k; ++kk)
			printf(" ");

		printf("    ");

		for(j = 0; j < lCharInLastLine; ++j)
		{
			if(isprint(pBin[16 * i + j]))
				printf("%c", pBin[16 * i + j]);
			else
				printf(".");
		}

		printf("\n");
	}
	printf("\n");
}

void Test99Time()
{
    ET_STATUS  retval;
	SYSTEMTIME st;
	int  limit;
	int  year, mon, day, hour, min, sec;
	BYTE updata[32];
    //================	
	printf("et_InitRTCTime()......");
	//
    GetLocalTime(&st);
	//
	retval = et_InitRTCTime(g_hToken, st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);    
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	}
    printf("OK\n");
	printf("write RTC: %d-%d-%d %d:%d:%d\r\n", st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);
	//================
	printf("et_GetRTCTime()......");	
	year = mon = day = hour = min = sec = 0;
	retval = et_GetRTCTime(g_hToken, &year, &mon, &day, &hour, &min, &sec);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	}
    printf("OK\n");
	printf("read RTC: %d-%d-%d %d:%d:%d\r\n", year, mon, day, hour, min, sec);
	//================
    printf("et_GenUpdateData()......");	
	memset(updata, 0, sizeof(updata));
    retval = et_GenUpdateData(g_hToken, 0, 24, 0, 0, 0, 0, 0, 0, updata);
	//retval = et_GenUpdateData(g_hToken, "1234567890ABCDEF", 0, 2009, 12, 31, 14, 36, 59, updata);
	//retval = et_GenUpdateData(g_hToken, "1234567890ABCDEF", -1, 0, 0, 0, 0, 0, 0, updata);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	}
    printf("OK\n");
	//================
	printf("et_UpdateTimeLimit()......");	
	retval = et_UpdateTimeLimit(g_hToken, updata);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	}
    printf("OK\n"); 
	//================
	printf("et_GetTimeLimit()......");	
	limit = year = mon = day = hour = min = sec = 0;
	retval = et_GetTimeLimit(g_hToken, &limit, &year, &mon, &day, &hour, &min, &sec);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	}
    printf("OK\n");
    printf("read LIMIT: hours:%d end:%d-%d-%d %d:%d:%d\r\n", limit, year, mon, day, hour, min, sec);
	//================	
}

void Test299()
{	
	ET_STATUS retval;
	int       i, len;
	unsigned char  tb;
	unsigned short tw;
	unsigned long  td;
	SYSTEMTIME* pst;
	unsigned char buf[512];
	//
    printf("et_SetKeyEx(ET_KEY_HMAC_MD5, 1, \"FFFFFFFFFFFFFFFF\") ......");	
	retval = et_SetKeyEx(g_hToken, ET_KEY_HMAC_MD5, 1, "FFFFFFFFFFFFFFFF");
	if(retval != ET_SUCCESS)
	{
       if(retval == 1)
	   {
         printf("Error: %2X  ... Need Input SOPIN to Access\n", retval);
	   }
	   else
	   {
          printf("Error: %2X\n", retval);
	   }
	   //
	   return;
	}
	printf("OK\n");
	//===========
    printf("et_SetKeyEx(ET_KEY_TDES, 1, \"FFFFFFFFFFFFFFFF\") ......");	
	retval = et_SetKeyEx(g_hToken, ET_KEY_TDES, 1, "FFFFFFFFFFFFFFFF");
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//===========
    printf("et_SetSNEx(\"1234567890ABCDEFGH\") ......");	
    retval = et_SetSNEx(g_hToken, "1234567890ABCDEFGH", 18);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//===========
	memset(buf, 0, sizeof(buf));
	len = sizeof(buf);  //������д����������
    printf("et_GetSNEx() ......");
	retval = et_GetSNEx(g_hToken, buf, &len);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\nSN_LEN=%d\nSN=%s\n", len, buf);
	//===========
    memset(buf, 0, sizeof(buf));
	printf("et_RSAGenKey(RSA_KEY_LEN_1024, pucKey, priKey) ......");
	retval = et_RSAGenKey(g_hToken, RSA_KEY_LEN_1024, buf, buf+256);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	printf("publicKEY:\n");
    ShowBinHex(buf, 128);
    printf("privateKEY:\n");
    ShowBinHex(buf+256, 128);
	//===========
	printf("et_RSASetKey(RSA_KEY_LEN_1024, pucKey, priKey) ......");
	retval = et_RSASetKey(g_hToken, RSA_KEY_LEN_1024, buf, buf+256);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n\n");	
	//===========
    memset(buf, 0, sizeof(buf));
    for(i=0; i<128; i++)
	{
       buf[i] = i;
	}
	printf("Original Data:\n");
    ShowBinHex(buf, 128);
	//===========
	printf("et_RSAPublicEncrypt(buf, 128, ET_RSA_NO_PADDING) ......");	
	//
	len = 128;
	//
	retval = et_RSAPublicEncrypt(g_hToken, buf, &len, ET_RSA_NO_PADDING); 
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//    
    printf("RSAPublicEncrypt Result:\n");
    ShowBinHex(buf, 128);
	//==========
	printf("et_RSAPrivateDecrypt(buf, 128, ET_RSA_NO_PADDING) ......");
	//
	len = 128;
	//
	retval = et_RSAPrivateDecrypt(g_hToken, buf, &len, ET_RSA_NO_PADDING); 
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//
    printf("RSAPrivateDecrypt Result:\n");
    ShowBinHex(buf, 128);
	//=========
    printf("et_RSAPrivateEncrypt(buf, 128, ET_RSA_NO_PADDING) ......");
	//
	len = 128;
	//
	retval = et_RSAPrivateEncrypt(g_hToken, buf, &len, ET_RSA_NO_PADDING); 
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//
    printf("RSAPrivateEncrypt Result:\n");
    ShowBinHex(buf, 128);
	//=========
    printf("et_RSAPublicDecrypt(buf, 128, ET_RSA_NO_PADDING) ......");
	//
	len = 128;
	//
	retval = et_RSAPublicDecrypt(g_hToken, buf, &len, ET_RSA_NO_PADDING); 
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//
    printf("RSAPublicDecrypt Result:\n");
    ShowBinHex(buf, 128);
	//=========
    printf("et_TDesEncrypt(1, buf ,128) ......");
	//
	retval = et_TDesEncrypt(g_hToken, 1, buf, 128); 
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//
    printf("TDesEncrypt Result:\n");
    ShowBinHex(buf, 128);
    //=========
    printf("et_TDesDecrypt(1, buf ,128) ......");
	//
	retval = et_TDesDecrypt(g_hToken, 1, buf, 128); 
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//
    printf("TDesDecrypt Result:\n");
    ShowBinHex(buf, 128);
	//=========
	printf("et_SetTimeLicense(0, ET_EXPIRE_DATE ,\"2020-01-02 12:16:18\") ......");
	//
    pst = (SYSTEMTIME*) buf;
	pst->wYear   = 2020;
	pst->wMonth  = 1;
	pst->wDay    = 2;
	pst->wHour   = 12;
	pst->wMinute = 16;
    pst->wSecond = 18;
	pst->wMilliseconds = 0;
	pst->wDayOfWeek    = 0;
	//
	retval = et_SetTimeLicense(g_hToken, 0, ET_EXPIRE_DATE, buf);
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//=========	
    printf("et_GetTimeLicense(0, &timeMode ,buf) ......");	
	//
	len = -1; //timeMode
	//
	retval = et_GetTimeLicense(g_hToken, 0, &len, buf);
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
    pst = (SYSTEMTIME*) buf;
	printf("timeMode=%d, ExpireTime=%04d-%02d-%02d %02d:%02d:%02d\n", len, pst->wYear, pst->wMonth, pst->wDay, pst->wHour, pst->wMinute, pst->wSecond);
	//=========
    printf("Clear Time License ......");
	//
	memset(buf, 0xFF, sizeof(buf));   //ȫ0xFF��ʾ�������
	//
    retval = et_SetTimeLicense(g_hToken, 0, ET_EXPIRE_DATE, buf);
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//=========
    printf("et_SetTimeLicense(0, ET_TIME_MINUTE , 120) ......");
	//
	*((int*)buf) = 120;
	//
	retval = et_SetTimeLicense(g_hToken, 0, ET_TIME_MINUTE, buf);
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//=========
    printf("et_StartTimeUnit(0) ......");	
	//
	retval = et_StartTimeUnit(g_hToken, 0);	
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//=========
    printf("et_StopTimeUnit(0) ......");	
	//
	retval = et_StopTimeUnit(g_hToken, 0);	
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//=========
    printf("Clear Time License ......");
	//
	memset(buf, 0xFF, sizeof(buf));   //ȫ0xFF��ʾ�������
	//
    retval = et_SetTimeLicense(g_hToken, 0, ET_TIME_MINUTE, buf);
	if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
    //=========
	printf("et_AdjustTimer() ......");
	//
	memset(buf, 0, sizeof(buf));
	//
    pst = (SYSTEMTIME*) buf;
	GetLocalTime(pst);
	//
	retval = et_AdjustTimer(g_hToken, buf);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//========
    printf("et_SetCountLicense(0, 100) ......");
	//
	retval = et_SetCountLicense(g_hToken, 0, 100, 1);  //ET_ENABLE_DECREASE = 1
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//========
    printf("et_GetCountLicense(0, &count) ......");
	//
	tb = 0;
	td = 0;
	retval = et_GetCountLicense(g_hToken, 0, &td, &tb);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\ncount=%d type=%d\n", td, tb);
    //========
    printf("et_GetCountLicense(0, &count) ......");
	//
	tb = 0;
	td = 0;
	retval = et_GetCountLicense(g_hToken, 0, &td, &tb);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\ncount=%d type=%d\n", td, tb);
	//========
    printf("Clear CountLicense ......");
	//
	retval = et_SetCountLicense(g_hToken, 0, -1, 0);  //ET_DISABLE_DECREASE = 0  ET_ENABLE_DECREASE = 1
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//========
    printf("et_GetCountLicense(0, &count) ......");
	//
	tb = 0;
	td = 0;
	retval = et_GetCountLicense(g_hToken, 0, &td, &tb);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\ncount=%d type=%d\n", td, tb);
	//========
    printf("et_GetVersion() ......");
	//
	tw = 0;
	retval = et_GetVersion(g_hToken, &tw);
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\nCosVersion=0X%04X\n", tw);	
	//========
    
}

void UpdateLic()
{
	ET_STATUS retval;
	FILE*       fp;
	unsigned char buf[512];
    //========
    memset(buf, 0, sizeof(buf));
	//
    printf("fopen(\"et299update.inc\") ......");
    fp = fopen("et299update.inc", "rb");  //������ֻ��
	if(fp == 0)
	{
       printf("Error\n");
	   return;
	}
	//
	fread(buf, 288, 1, fp);
	fclose(fp);
	printf("OK\n");
	//========
    printf("et_Verify(ET_VERIFY_USERPIN, \"FFFFFFFFFFFFFFFFetrockeyFFC5EB78\") ......");
	//
	retval = et_Verify(g_hToken, ET_VERIFY_USERPIN, "FFFFFFFFFFFFFFFFetrockeyFFC5EB78");
    //
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//========
    printf("et_CheckUpdateFile(buf+32, 128) ......");
	//
	retval = et_CheckUpdateFile(g_hToken, buf+32, 128);
    //
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");
	//========
	printf("et_RemoteUpdate() ......");
	//
	retval = et_RemoteUpdate(g_hToken, buf+32+128, 288-32-128);
    //
    if(retval != ET_SUCCESS)
	{
       printf("Error: %2X\n", retval);
	   return;
	}
	printf("OK\n");	
}

void ShowSetupMenu()
{
	ET_STATUS retval = ET_SUCCESS;
	int  len;
	char Pin[16] = {0};
	unsigned char newPin[16];
	unsigned char soPin[17];
	char iBuf[51] = {0};
	unsigned char seed[51]={0};
	//char soPin[16];
	BYTE bSoPINRetries;
	BYTE bUserPINRetries;
	BYTE bUserReadOnly;
	char buff;
	//
	while(1)
	{
		//HANDLE hStd=GetStdHandle(STD_OUTPUT_HANDLE); 
		//SetConsoleTextAttribute(hStd,FOREGROUND_INTENSITY|FOREGROUND_BLUE|FOREGROUND_GREEN);
		printf("\n\nSetup menu:\n");
		printf("-------------------------------------------------------------\n");
		printf("  User[P]IN          Gen[S]OPIN          [R]esetUserPIN \n");
		printf("  Setup[T]oken       E[X]it\n\n");
		//SetConsoleTextAttribute(hStd,FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_RED);
		switch(WaitForUserInput())
		{
		case 'P':
		case 'p':
			{				
				printf("\nChange User PIN\n");				
				printf("Input old User PIN <16>:");
				fflush(stdin);
				gets(Pin);
				printf("Input new User PIN <16>:");
				fflush(stdin);
				gets((char *)newPin);
				retval = et_ChangeUserPIN(g_hToken,(unsigned char *)Pin,(unsigned char *)newPin);
				ShowErrInfo(retval);
			}
			break;
		case 'S':
		case 's':
			{
				
				soPin[16]='\0';
				
				printf("Please input seed <1-51>: ");
				fflush(stdin);
				gets((char*)seed);
				//
				len = strlen((char *)seed);
				retval = et_GenSOPIN(g_hToken,len,seed,soPin);
				ShowErrInfo(retval);
				if(ET_SUCCESS == retval)
				{
					printf("The new SO PIN is : \n");
					printf("%s",(char*)soPin);
				}
			}
			break;
		case 'R':
		case 'r':
			{
				
				printf("Please input the SO PIN <16>: ");
				fflush(stdin);
				gets(soPin);
				retval = et_ResetPIN(g_hToken,(unsigned char *)soPin);
				ShowErrInfo(retval);
			}
			break;
		case 'T':
		case 't':
			{
				
				printf("Please input SO PIN retry count <0-15>:");
				fflush(stdin);
				gets(&buff);
				sscanf(&buff,"%ld",&bSoPINRetries);

				printf("Please input User PIN retry count <0-15>:");
				fflush(stdin);
				gets(&buff);
				sscanf(&buff,"%ld",&bUserPINRetries);

				printf("Please input user read or write data zone flags <0 or 1>:");
				fflush(stdin);
				gets(&buff);
				sscanf(&buff,"%ld",&bUserReadOnly);
				
				retval = et_SetupToken(g_hToken,bSoPINRetries,bUserPINRetries,bUserReadOnly,0);
				ShowErrInfo(retval);
			}
			break;
		case 'X':
		case 'x':
			return;
		default:
			break;
		}
	}
}

void ShowCryptMenu()
{
	ET_STATUS retval = ET_SUCCESS;
	unsigned long fid1 = 0;
	unsigned long fid2 = 0;
	char tBuf[32] = {0};
	int keyIndex=0;
	unsigned char key[32] = {0};
    char text[80] = {0};
    unsigned char Dig1[16] = {0};
	unsigned char Dig2[16] = {0};
    char skey[80] = {0};
    char tmpBuf[32] = {0};
	int index = 0;
	char hkey[80] = {0};
	unsigned char tDig[16] = {0};
	//
	while(1)
	{
		//HANDLE hStd=GetStdHandle(STD_OUTPUT_HANDLE); 
		//SetConsoleTextAttribute(hStd,FOREGROUND_INTENSITY|FOREGROUND_BLUE|FOREGROUND_GREEN);
		printf("\n\nCrypt Menu:\n");
		printf("-------------------------------------------------------------\n");
		printf("  [M]akeHMACKey    [H]MAC     E[X]it\n");
		//SetConsoleTextAttribute(hStd,FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_RED);
		switch(WaitForUserInput())
		{
		case 'H':
		case 'h':
			{
				printf("\nUsing key for HMAC-MD5 authentication\n\n");

				
				printf("Input index of the key <1-8>:");
				fflush(stdin);
				gets(tBuf);
				sscanf(tBuf,"%ld",&keyIndex);
				
				fflush(stdin);
				printf("Input random data for HMAC-MD5 authentication(MAX 51 bytes):");
				gets(text);
				
				retval = et_HMAC_MD5(g_hToken,keyIndex,strlen(text),(unsigned char *)text,Dig1);
				ShowErrInfo(retval);
				if(ET_SUCCESS!=retval)
					break;
				ShowBinHex(Dig1,16);
				
				printf("\n\nPleas input the	secret HMAC-MD5 key to verify:");
				
				fflush(stdin);
				gets(skey);
				retval = MD5_HMAC((unsigned char*)text,strlen((char*)text),(unsigned char*)skey,strlen(skey),key,Dig2);
				ShowErrInfo(retval);
				if(ET_SUCCESS!=retval)
					break;
				printf("Software HMAC-MD5 compute result:\n");
				ShowBinHex(Dig2,16);
				
				if(memcmp(Dig1,Dig2,16))
				{
					printf("Verify failed!");
				}
				else
				{
					printf("Verify successfully!");
				}
			}
			break;
		case 'M':
		case 'm':
			{
				printf("\n Create key files for HMAC-MD5 authentication.\n\n");
				
				printf("Input index of the key <1-8>:");
				fflush(stdin);
				gets(tmpBuf);
				sscanf(tmpBuf,"%ld",&index);

				printf("Input the secret HMAC-MD5 key:");
				
				fflush(stdin);
				gets(hkey);
				
				
				retval = MD5_HMAC(NULL,0,(unsigned char*)hkey,strlen(hkey),key,tDig);
				ShowErrInfo(retval);
				if(ET_SUCCESS!=retval)
					break;

				printf("HMAC-MD5 key content:\n");
				ShowBinHex(key,32);

				retval = et_SetKey(g_hToken,index,key);
				ShowErrInfo(retval);
			}
			break;
		case 'X':
		case 'x':
			return;
		default:
			break;
		}
	}
}

void ShowDataMenu()
{
	ET_STATUS retval = ET_SUCCESS;
    unsigned char iBuf7[80] = {0};
	unsigned long offs = 0;
	unsigned long rLen = 0;
	unsigned char rBuff[500] = {0};
	unsigned long off2 = 0;
	unsigned char iBuf8[80] = {0};
	unsigned long rLen2 = 0;
	unsigned long index = 0;
	char keyData[33];
    //
	while(1)
	{
		//HANDLE hStd=GetStdHandle(STD_OUTPUT_HANDLE); 
		//SetConsoleTextAttribute(hStd,FOREGROUND_INTENSITY|FOREGROUND_BLUE|FOREGROUND_GREEN);	
		printf("\n\nData Menu:\n");
		printf("-------------------------------------------------------------\n");
		printf(	"  [R]ead   [W]rite   Set[K]ey   E[X]it\n" );
		//SetConsoleTextAttribute(hStd,FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_RED);
		switch(WaitForUserInput())
		{
		case 'R':
		case 'r':
			{
				
				printf("Input offset to begin read <0-6000>:");
				fflush(stdin);
				gets((char*)iBuf7);
				sscanf((char*)iBuf7,"%ld",&offs);
				printf("Input number of byte to read <0-500>:");
				
				fflush(stdin);
				gets((char*)iBuf7);
				sscanf((char*)iBuf7,"%ld",&rLen);
				
				retval = et_Read(g_hToken,(unsigned short)offs,(unsigned short)rLen,rBuff);
				ShowErrInfo(retval);
				if(ET_SUCCESS == retval)
				{
					printf("\n =>> %ld (0x%X) byte%s read.\n", rLen, rLen, rLen > 1 ? "s" : "");
					ShowBinHex(rBuff,rLen);
				}
			}
			break;
		case 'W':
		case 'w':
			{
				
				printf("Input offset to begin write <0-6000>:");
				fflush(stdin);
				gets((char*)iBuf8);
				sscanf((char*)iBuf8,"%ld",&off2);
				printf("Input data to write <0-500>:");
				fflush(stdin);
				gets((char*)iBuf8);
				
				rLen2 = strlen((char*)iBuf8);
				printf("\n =>> %ld byte%s to write.\n",rLen2, rLen2 > 1 ? "s" : "");
				ShowBinHex(iBuf8,rLen2);
				 
				retval = et_Write(g_hToken,(unsigned short)off2,(unsigned short)rLen2,(unsigned char *)iBuf8);
				ShowErrInfo(retval);
				if(ET_SUCCESS == retval)
				{
					printf("\n =>> %ld byte%s written successfully!",rLen2, rLen2 > 1 ? "s" : "");
				}
			}
			break;
		case 'K':
		case 'k':
			{
				
				printf("Input Key's index <1-8>:");
				fflush(stdin);
				gets((char*)iBuf8);
				sscanf((char*)iBuf8,"%ld",&index);
				printf("Input Key(32):");
				fflush(stdin);
				gets(keyData);
				retval = et_SetKey(g_hToken,index,(unsigned char *)keyData);
				ShowErrInfo(retval);
			}
			break;
		case 'X':
		case 'x':
			return;
		}
	}
}

int main(int argc, char* argv[])
{
	ET_STATUS retval = ET_SUCCESS;
	int count = 0;
	char iBuf[80] = {0};
	unsigned char SN[8];
	unsigned char pid[9];
	unsigned char seed[51];	
	char Pin[16] = {0};
	char sopin[16] = {0};
	unsigned char rBuf[16] = {0};
    //
	ShowBanner();
	
	while(1)
	{
		ShowMainCmdMenu();
		switch(WaitForUserInput())
		{
		case 'F':
		case 'f':
			{				
				printf("Input PID <8>: ");
				fflush(stdin);
				gets(iBuf);
				//sscanf(iBuf,"%lx",&PID);
				retval = et_FindToken((unsigned char*)iBuf,&count);
				ShowErrInfo(retval);
				if(ET_SUCCESS == retval)
					printf("Find %ld ET299.\n",count);
			}
			break;
		case 'N':
		case 'n':
			{				
				retval = et_GetSN(g_hToken,SN);
				ShowErrInfo(retval);
				if(ET_SUCCESS == retval)
				{
					printf("The SN is : \n");
					ShowBinHex(SN,8);
				}
			}
			break;
		case 'I':
		case 'i':
			{
				
				pid[8]='\0';
				
				printf("Please input seed <1-51>: ");
				fflush(stdin);
				gets(iBuf);
				memcpy(seed,iBuf,strlen(iBuf));
				retval = et_GenPID(g_hToken,strlen(iBuf),seed,pid);
				ShowErrInfo(retval);
				if(ET_SUCCESS == retval)
				{
					printf("The new PID is : %s\n",(char*)pid);
				}
			}
			break;
		case 'T':
		case 't':
			{
				
				printf("Please input PID <8>: ");
				fflush(stdin);
				gets(iBuf);
				//sscanf(iBuf,"%lx",&pid);
				retval = et_OpenToken(&g_hToken,(unsigned char*)iBuf,1);
				ShowErrInfo(retval);
			}
			break;
		case 'O':
		case 'o':
			printf("\nTurn LED on:");
			retval = et_TurnOnLED(g_hToken);
			ShowErrInfo(retval);
			break;
		case 'P':
		case 'p':
			{
				
				printf("Input PIN <16>:");
				fflush(stdin);
				gets(Pin);
				retval = et_Verify(g_hToken,ET_VERIFY_USERPIN,(unsigned char *)Pin);
				ShowErrInfo(retval);
			}
			break;
		case 'A':
		case 'a':
			ShowDataMenu();
			break;
		case 'D':
		case 'd':
			printf("\nTurn LED off:");
			retval = et_TurnOffLED(g_hToken);
			ShowErrInfo(retval);
			break;
		case 'S':
		case 's':
			{
				
				printf("Input SO PIN <16>:");
				fflush(stdin);
				gets(sopin);
				retval = et_Verify(g_hToken,ET_VERIFY_SOPIN,(unsigned char*)sopin);
				ShowErrInfo(retval);
			}
			break;
		case 'M':
		case 'm':
			{
				printf("Generate random \n");
				
				retval = et_GenRandom(g_hToken,rBuf);
				ShowErrInfo(retval);
				if(ET_SUCCESS == retval)
				{
					ShowBinHex(rBuf,16);
				}
			}
			break;
		case 'Y':
		case 'y':
			ShowCryptMenu();
			break;
		case 'R':
		case 'r':
			//printf("Reset token:");
			retval = et_ResetSecurityState(g_hToken);
			ShowErrInfo(retval);
			break;
		case 'U':
		case 'u':
			ShowSetupMenu();
			break;
		case 'C':
		case 'c':
			printf("\nClose device:");
			retval = et_CloseToken(g_hToken);
			ShowErrInfo(retval);
			break;
		case '9':
			printf("Test Start \n");
			Test299();
            printf("Test End\n");
			break;
        case 'E':
        case 'e':
            printf("Test ET99 Time Start \n");
			Test99Time();
            printf("Test ET99 Time End\n");
			break;
        case 'L':
		case 'l':
			printf("Test UpdateLicense \n");
			UpdateLic();
            printf("Test End\n");
			break;
		case 'X':
		case 'x':
			et_CloseToken(g_hToken);
			return 0;
		default:
			break;
		}
	}
}




