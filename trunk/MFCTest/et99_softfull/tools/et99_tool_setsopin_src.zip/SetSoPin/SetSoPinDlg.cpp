// SetSoPinDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SetSoPin.h"
#include "SetSoPinDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetSoPinDlg dialog

CSetSoPinDlg::CSetSoPinDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetSoPinDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetSoPinDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSetSoPinDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetSoPinDlg)
	DDX_Control(pDX, BUTTON_SET, m_btnSet);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSetSoPinDlg, CDialog)
	//{{AFX_MSG_MAP(CSetSoPinDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(BUTTON_EXIT, OnExit)
	ON_BN_CLICKED(BUTTON_SET, OnSet)
	ON_EN_CHANGE(EDIT_PID, OnChangePid)
	ON_EN_CHANGE(EDIT_OLDSOPIN, OnChangeOldsopin)
	ON_EN_CHANGE(EDIT_SEED, OnChangeSeed)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetSoPinDlg message handlers

BOOL CSetSoPinDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSetSoPinDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSetSoPinDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSetSoPinDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSetSoPinDlg::OnExit() 
{
	CDialog::OnOK();
}

void CSetSoPinDlg::OnSet() 
{
	// �������
	unsigned char longPid[8];
	int tokenCount;
	ET_HANDLE hET99;
	unsigned long ret = ET_SUCCESS;
	char chSoPin[17];

	GetDlgItemText(EDIT_PID,Pid);
	GetDlgItemText(EDIT_OLDSOPIN,OldSoPin);
	GetDlgItemText(EDIT_SEED,Seed);
	memcpy(longPid,Pid.GetBuffer(0),8);
	//sscanf(Pid.GetBuffer(0),"%lx",&longPid);
	ret = et_FindToken(longPid,&tokenCount);
	if(ET_SUCCESS!=ret)
	{
		MessageBox("�Ҳ���ָ����ET99!","SetSOPIN",MB_OK|MB_ICONSTOP);
		return;
	}
	else
	{
		if(1!=tokenCount)
		{
			MessageBox("�ҵ�ָ����ET99��ֹ1��!","SetSOPIN",MB_OK|MB_ICONSTOP);
			return;
		}
	}
	ret = et_OpenToken(&hET99,longPid,1);
	if(ET_SUCCESS!=ret)
	{
		MessageBox("��ET99ʧ��!","SetSOPIN",MB_OK|MB_ICONSTOP);
		return;
	}
	ret = et_Verify(hET99,1,(unsigned char *)OldSoPin.GetBuffer(0));
	if(ET_SUCCESS!=ret)
	{
		MessageBox("�����û�PIN�����!","SetSOPIN",MB_OK|MB_ICONSTOP);
		et_CloseToken(hET99);
		return;
	}
	ret = et_GenSOPIN(hET99,Seed.GetLength(),(unsigned char *)Seed.GetBuffer(0),(unsigned char*)chSoPin);
	if(ET_SUCCESS!=ret)
	{
		MessageBox("���ó����û�PIN��ʧ��!","SetSOPIN",MB_OK|MB_ICONSTOP);
		et_CloseToken(hET99);
		return;
	}
	else
	{
		chSoPin[16]='\0';
		CString NewSoPin((char *)chSoPin);
		SetDlgItemText(EDIT_NEWSOPIN,NewSoPin);
		MessageBox("���ó����û�PIN��ɹ� ! ","SetSOPIN",MB_OK|MB_ICONINFORMATION);
	}
	et_CloseToken(hET99);
}

void CSetSoPinDlg::OnChangePid() 
{
	GetDlgItemText(EDIT_PID,Pid);
	GetDlgItemText(EDIT_OLDSOPIN,OldSoPin);
	GetDlgItemText(EDIT_SEED,Seed);
	if((8!=Pid.GetLength())||(16!=OldSoPin.GetLength())||(0==Seed.GetLength())||(Seed.GetLength()>51))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
}

void CSetSoPinDlg::OnChangeOldsopin() 
{
	GetDlgItemText(EDIT_PID,Pid);
	GetDlgItemText(EDIT_OLDSOPIN,OldSoPin);
	GetDlgItemText(EDIT_SEED,Seed);
	if((8!=Pid.GetLength())||(16!=OldSoPin.GetLength())||(0==Seed.GetLength())||(Seed.GetLength()>51))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);	
}

void CSetSoPinDlg::OnChangeSeed() 
{
	GetDlgItemText(EDIT_PID,Pid);
	GetDlgItemText(EDIT_OLDSOPIN,OldSoPin);
	GetDlgItemText(EDIT_SEED,Seed);
	if((8!=Pid.GetLength())||(16!=OldSoPin.GetLength())||(0==Seed.GetLength())||(Seed.GetLength()>51))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
}

void CSetSoPinDlg::OnOK() 
{
	// TODO: Add extra validation here
	
//	CDialog::OnOK();
}
