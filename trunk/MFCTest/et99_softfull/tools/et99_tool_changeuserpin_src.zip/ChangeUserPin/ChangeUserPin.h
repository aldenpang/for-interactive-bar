// ChangeUserPin.h : main header file for the ChangeUserPin application
//

#if !defined(AFX_ChangeUserPin_H__6B6C3AD3_D2EA_41CE_B581_8571932D1402__INCLUDED_)
#define AFX_ChangeUserPin_H__6B6C3AD3_D2EA_41CE_B581_8571932D1402__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CChangeUserPinApp:
// See ChangeUserPin.cpp for the implementation of this class
//

class CChangeUserPinApp : public CWinApp
{
public:
	CChangeUserPinApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChangeUserPinApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CChangeUserPinApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ChangeUserPin_H__6B6C3AD3_D2EA_41CE_B581_8571932D1402__INCLUDED_)
