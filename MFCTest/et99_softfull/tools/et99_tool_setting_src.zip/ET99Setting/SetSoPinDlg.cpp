// SetSoPinDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SetSoPin.h"
#include "SetSoPinDlg.h"
#include "UpdataUidDlg.h"
#include "Fileini.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}
 
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetSoPinDlg dialog

CSetSoPinDlg::CSetSoPinDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSetSoPinDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSetSoPinDlg)
	m_pid = _T("");
	m_oldpin = _T("");
	m_dowhile = FALSE;
	m_olduid = _T("");
	m_sopinnum = _T("");
	m_upinnum = _T("");
	m_readw = FALSE;
	m_pidflg = FALSE;
	m_readwflg = FALSE;
	m_sopinflg = FALSE;
	m_upinflg = FALSE;
	m_newupin = _T("");
	m_seed = _T("");
	m_newpid = _T("");
	m_newsopin = _T("");
	m_oldpid = _T("");
	m_SopinSeed = _T("");
	//}}AFX_DATA_INIT
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSetSoPinDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSetSoPinDlg)
	DDX_Control(pDX, BUTTON_SET, m_btnSet);
	DDX_Text(pDX, EDIT_PID, m_pid);
	DDX_Text(pDX, EDIT_OLDSOPIN, m_oldpin);
	DDX_Text(pDX, EDIT_OLDUID, m_olduid);
	DDX_Text(pDX, IDC_EDITSOPINNUM, m_sopinnum);
	DDX_Text(pDX, IDC_EDITUPINNUM, m_upinnum);
	DDX_Check(pDX, IDC_CHECKREADW, m_readw);
	DDX_Check(pDX, IDC_CHECKPIDFLG, m_pidflg);
	DDX_Check(pDX, IDC_CHECKREADWFLG, m_readwflg);
	DDX_Check(pDX, IDC_CHECKSOPINFLG, m_sopinflg);
	DDX_Check(pDX, IDC_CHECKUSERPIN, m_upinflg);
	DDX_Text(pDX, EDIT_NEWUID, m_newupin);
	DDX_Text(pDX, EDIT_SEED, m_seed);
	DDX_Text(pDX, EDIT_NEWPID, m_newpid);
	DDX_Text(pDX, EDIT_NEWSOPIN, m_newsopin);
	DDX_Text(pDX, EDIT_OLDPID, m_oldpid);
	DDX_Text(pDX, EDIT_SOPIN_SEED, m_SopinSeed);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSetSoPinDlg, CDialog)
	//{{AFX_MSG_MAP(CSetSoPinDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(BUTTON_EXIT, OnExit)
	ON_BN_CLICKED(BUTTON_SET, OnSet)
	ON_EN_CHANGE(EDIT_OLDSOPIN, OnChangeOldsopin)
	ON_EN_CHANGE(EDIT_SEED, OnChangeSeed)
	ON_BN_CLICKED(BUTTON_RESET, OnReset)
	ON_BN_CLICKED(IDC_BUTHelp, OnButUpdataUid)
	ON_EN_CHANGE(IDC_EDITSOPINNUM, OnChangeEditsopinnum)
	ON_BN_CLICKED(IDC_BUTHOISTRY, OnButhoistry)
	ON_BN_CLICKED(BUTTON_RESET2, OnUpUpin)
	ON_WM_CTLCOLOR()
	ON_EN_CHANGE(EDIT_OLDPID, OnChangeOldpid)
	ON_EN_CHANGE(EDIT_OLDUID, OnChangeOlduid)
	ON_EN_CHANGE(EDIT_NEWUID, OnChangeNewuid)
	ON_EN_CHANGE(EDIT_SOPIN_SEED, OnChangeSopinSeed)
	ON_EN_CHANGE(IDC_EDITUPINNUM, OnChangeEditupinnum)
	ON_BN_CLICKED(IDC_CHECKPIDFLG, OnCheckpidflg)
	ON_BN_CLICKED(IDC_CHECKSOPINFLG, OnChecksopinflg)
	ON_BN_CLICKED(IDC_CHECKUSERPIN, OnCheckuserpin)
	ON_BN_CLICKED(IDC_CHECKREADWFLG, OnCheckreadwflg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSetSoPinDlg message handlers

BOOL CSetSoPinDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	
	//����Ĭ�ϵ�ֵ
	UpdateData(TRUE);
	//m_pid.Format("F737F785");
    //m_oldpin.Format("F737F7856A874DC8");  
    m_oldpid.Format("FFFFFFFF");
    m_oldpin.Format("FFFFFFFFFFFFFFFF"); 
    m_olduid.Format("FFFFFFFFFFFFFFFF");    
    m_newupin.Format("");
    m_seed.Format("");
    m_newpid.Format("");

	m_sopinnum.Format("0");
	m_upinnum.Format("0");

	UpdateData(FALSE);

	//��INI�ļ�
    DWORD cchCurDir=MAX_PATH; 
	LPTSTR lpszCurDir; 
	TCHAR tchBuffer[MAX_PATH];
	lpszCurDir = tchBuffer;	
	
	GetCurrentDirectory(cchCurDir, lpszCurDir);
	
	fileini.SetIniPath(lpszCurDir);
	fileini.SetIniFilename("\\History.ini");
	fileini.OpenFileini();

	//==========
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSetSoPinDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSetSoPinDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSetSoPinDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSetSoPinDlg::OnExit() 
{
	CDialog::OnOK();
}

BOOL CSetSoPinDlg::OpenDevice()
{
   	// �������

	int tokenCount;
	unsigned long ret = ET_SUCCESS;

	ret = et_FindToken(longPid,&tokenCount);

	if(ET_SUCCESS!=ret)
	{
		MessageBox("�Ҳ���ָ����ET99!","OpenEt99",MB_OK|MB_ICONSTOP);
		return FALSE;
	}
	else
	{
		if(1!=tokenCount)
		{// YUHZ[11/27/2006] ������ý����ҵ�����ET99����ʾ��������˵���ù���һ��ֻ��ʼ��һ��ET99��
			char temp[10]={0};
			sprintf(temp,"%d",tokenCount);
			char txt[MAX_PATH]={0};
			lstrcat(txt,"�ҵ�");
			lstrcat(txt,temp);
			lstrcat(txt,"��ָ����ET99��һ��ֻ�ܳ�ʼ��һ��ET99��");
			MessageBox(txt,"OpenEt99",MB_OK|MB_ICONSTOP);
			return FALSE;
		}
	}

	ret = et_OpenToken(&hET99,longPid,1);
	if(ET_SUCCESS!=ret)
	{
		MessageBox("��ET99ʧ��!","OpenEt99",MB_OK|MB_ICONSTOP);
		return FALSE;
	}
//	// YUHZ[11/27/2006]����OpenDriver()����֤�����û�PIN������ϲ�������Ӧ���õ��������档���⣬����Ҳ��ǡ����������ԸĽ�OpenDevice()����ʲô�� 
//	ret = et_Verify(hET99,ET_VERIFY_SOPIN,(unsigned char *)OldSoPin.GetBuffer(0));
//
//	if(ET_SUCCESS!=ret)
//	{
//		MessageBox("�����û�PIN�����!","OpenEt99",MB_OK|MB_ICONSTOP);
//		et_CloseToken(hET99);
//		return FALSE;
//	}
   return TRUE;
}


void CSetSoPinDlg::OnSet() 
{
	char chSoPin[17];
	unsigned char newPid[8];
	unsigned long ret = ET_SUCCESS;

	if(m_sopinflg)
	{
		if(m_SopinSeed == m_seed)
		{
			if(IDYES!=MessageBox("����PID�����ӺͲ���SOPIN��������һ����,�������ڰ�ȫ����!�����Ƿ����?","InitET99",MB_YESNO))
				return;
		}
	}	
   
	//===========

	UpdateData(TRUE);
	// YUHZ[11/27/2006] ע�⣡���ڲ���SOPIN��PID������Ӧ�ò�ͬ������ή�Ͱ�ȫ�ԡ�����Ӧ����������������� 
	GetDlgItemText(EDIT_PID,Pid);              //Ӳ��PID
	GetDlgItemText(EDIT_OLDSOPIN,OldSoPin);    //SOPIN��
	GetDlgItemText(EDIT_SEED,Seed);            //����
    GetDlgItemText(EDIT_OLDUID,Uid);           //�ɵ��û���
	GetDlgItemText(EDIT_NEWUID,NewUid);        //�µ��û���
    
	memcpy(longPid,Pid.GetBuffer(0),8);
    
	//����ϴβ������µ�SO PIN ���µ�����PID
	m_newsopin.Empty();
    m_newpid.Empty();
    UpdateData(FALSE);

	if(m_pidflg || m_sopinflg || m_upinflg ||  m_readwflg)
	{
		//========================����Ӳ��PID
		if(m_pidflg)
		{
			if(!OpenDevice())
			{
			  return;
			}

			ret = et_Verify(hET99,ET_VERIFY_SOPIN,(unsigned char *)OldSoPin.GetBuffer(0));
			if(ET_SUCCESS!=ret)
			{
				MessageBox("�����û�PIN�����!","SetTokenPID",MB_OK|MB_ICONSTOP);
				et_CloseToken(hET99);
				return;
			}
  
			ret = et_GenPID(hET99,Seed.GetLength(),(unsigned char *)Seed.GetBuffer(0),newPid);
			if(ET_SUCCESS!=ret)
			{
				MessageBox("����Ӳ��PIDʧ��!","SetTokenPID",MB_OK|MB_ICONSTOP);
				et_CloseToken(hET99);
				return;
			}
			else
			{
				char NewChPid[9];
				memcpy(NewChPid,newPid,8);
				//���µ�Ӳ��PID��ֵ
				memcpy(longPid,newPid,8);
				NewChPid[8]='\0';
				CString CSPid(NewChPid);
				
				//д��INI�ļ���			
				fileini.WriteKeyVar("ET99","PID����",Seed);
				fileini.WriteKeyVar("ET99","Ӳ��PID",CSPid);

				SetDlgItemText(EDIT_NEWPID,CSPid);
				MessageBox("����Ӳ��PID�ɹ� ! ","SetTokenPID",MB_OK|MB_ICONINFORMATION);
			}
		}
		
		//=====================================
		
		//================���ó����û�PIN��
		if(m_sopinflg )
		{
			if(!OpenDevice())
			{
				return;
			}

			ret = et_Verify(hET99,ET_VERIFY_SOPIN,(unsigned char *)OldSoPin.GetBuffer(0));
			if(ET_SUCCESS!=ret)
			{
				MessageBox("�����û�PIN�����!","OpenEt99",MB_OK|MB_ICONSTOP);
				et_CloseToken(hET99);
				return;
			}

			ret = et_GenSOPIN(hET99,m_SopinSeed.GetLength(),(unsigned char *)m_SopinSeed.GetBuffer(0),(unsigned char*)chSoPin);
			if(ET_SUCCESS!=ret)
			{
				MessageBox("���ó����û�PIN��ʧ��!","SetSOPIN",MB_OK|MB_ICONSTOP);
				et_CloseToken(hET99);
				return;
			}
			else
			{   
				chSoPin[16]='\0'; 
				//�����µ�SOPIN�� 
				OldSoPin=chSoPin;
				CString NewSoPin((char *)chSoPin);
				SetDlgItemText(EDIT_NEWSOPIN,NewSoPin);
                
				//д��INI�ļ���				
				fileini.WriteKeyVar("ET99","SOPIN����",m_SopinSeed);
				fileini.WriteKeyVar("ET99","SO PIN",NewSoPin);

				MessageBox("���ó����û�PIN��ɹ� ! ","SetSOPIN",MB_OK|MB_ICONINFORMATION);
			}
			
		}
		
		//==================================
		
		//=================�����û�PIN��
		if(m_upinflg )
		{
			if(!OpenDevice())
			{
				return;
			}
//			// YUHZ[11/27/2006] ������ƣ�et_ChangeUserPIN����������״̬�½��У�����Ҫ����֤�û�PIN�� 
//			//��֤�û���
//			ret = et_Verify(hET99,ET_VERIFY_USERPIN,(unsigned char *)Uid.GetBuffer(0));
//			if(ET_SUCCESS!=ret)
//			{
//				MessageBox("�û�PIN�����!","UpUserPIN",MB_OK|MB_ICONSTOP);		
//				et_CloseToken(hET99);
//			}
//			else
			{
				ret = et_ChangeUserPIN(hET99,(unsigned char *)Uid.GetBuffer(0),(unsigned char *)NewUid.GetBuffer(0));
				
				if(ET_SUCCESS!=ret)
				{
					if(ret == ET_NOT_SET_PID)
						MessageBox("�㻹û���������ET99��PID!","ChangeUserPin",MB_OK|MB_ICONSTOP);
					else
						MessageBox("�ı��û�PIN�����!","ChangeUserPin",MB_OK|MB_ICONSTOP);
					et_CloseToken(hET99);
					return;
				}

				//д��INI�ļ���				
				fileini.WriteKeyVar("ET99","�µ�User PIN",NewUid);
     
				MessageBox("�ı��û�PIN��ɹ�!","ChangeUserPin",MB_OK);
				et_CloseToken(hET99);			
			}
			
		}
		
		//==================================
		
		//================��������
		if(m_readwflg)
		{
			if(!OpenDevice())
			{
				return;
			}
			ret = et_Verify(hET99,ET_VERIFY_SOPIN,(unsigned char *)OldSoPin.GetBuffer(0));
			if(ET_SUCCESS!=ret)
			{
				MessageBox("�����û�PIN�����!","OpenEt99",MB_OK|MB_ICONSTOP);
				et_CloseToken(hET99);
				return;
			}
			
			BYTE SoPinRetryCount=0;       //SOPIN��Ķ�д����
			BYTE UserPinRetryCount=0;     //UID��Ķ�д����
			BOOL ReadOnlyFlag=0;          //ֻ������
			
			UpdateData(TRUE);
			
			
			SoPinRetryCount=atoi(m_sopinnum);
			UserPinRetryCount=atoi(m_upinnum);
			ReadOnlyFlag=m_readw;
			
			if(ReadOnlyFlag) ReadOnlyFlag=ET_USER_READ_ONLY; //ֻ��
			
			if((0>SoPinRetryCount)||(15<SoPinRetryCount)||(0>UserPinRetryCount)||(15<UserPinRetryCount)||!(ReadOnlyFlag==0||ReadOnlyFlag==1))
			{
				MessageBox("��������д���!","SetupToken",MB_OK|MB_ICONSTOP);
				et_CloseToken(hET99);
				return;
			}
			ret = et_SetupToken(hET99,SoPinRetryCount,UserPinRetryCount,ReadOnlyFlag,0);
			if(ET_SUCCESS!=ret)
			{
				MessageBox("����ET99ʧ��!","SetupToken",MB_OK|MB_ICONSTOP);
				et_CloseToken(hET99);
				return;
			}
			else
			{
				char sopincount[5]={0};
				char userpincount[5]={0};
				sprintf(sopincount,"%d",SoPinRetryCount);
				sprintf(userpincount,"%d",UserPinRetryCount);
				fileini.WriteKeyVar("ET99","SO PIN�����Դ���",sopincount);
				fileini.WriteKeyVar("ET99","User PIN�����Դ���",userpincount);
				if(m_readw)
					fileini.WriteKeyVar("ET99","��д����","ֻ��");
				else
					fileini.WriteKeyVar("ET99","��д����","�ɶ�д");
				MessageBox("����ET99���Գɹ�! ","SetupToken",MB_OK|MB_ICONINFORMATION);
			}
		}
		//====================================
	}
	else
	{
		MessageBox("��ѡ��������!","Et99 Setting",MB_OK|MB_ICONINFORMATION);
		return ;
	}


}

void CSetSoPinDlg::OnChangeOldsopin() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnChangeSeed() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}

	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnOK() 
{
	// TODO: Add extra validation here
	
//	CDialog::OnOK();
}

void CSetSoPinDlg::OnReset() 
{
	//����Ĭ�ϵ�ֵ
	UpdateData(TRUE);
	m_oldpid.Format("FFFFFFFF");
    m_oldpin.Format("FFFFFFFFFFFFFFFF");    
    m_olduid.Format("FFFFFFFFFFFFFFFF");    
    m_newupin.Format("");
    m_seed.Format("");
    m_newpid.Format("");
	m_SopinSeed.Format("");
    
	m_sopinnum.Format("0");
	m_upinnum.Format("0");

	UpdateData(FALSE);
}

void CSetSoPinDlg::OnButUpdataUid() 
{   
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CSetSoPinDlg::OnChangeEditsopinnum() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}



void CSetSoPinDlg::OnButhoistry() 
{ 
    ShellExecute(NULL,"open",fileini.sPathFilename,NULL,NULL,SW_SHOWNORMAL);      
}

void CSetSoPinDlg::OnUpUpin() 
{
	GetDlgItemText(EDIT_PID,Pid);
	GetDlgItemText(EDIT_OLDSOPIN,OldSoPin);	
	GetDlgItemText(EDIT_OLDUID,Uid);	
   
	if(Uid.IsEmpty())
	{
		::AfxMessageBox("�û�PIN����Ϊ��!����������");
		return ;
	}
    CUpdataUidDlg UpuidDlg;  
	

	memcpy(UpuidDlg.longPid ,Pid.GetBuffer(0),8);

    memcpy(UpuidDlg.chSoPin,OldSoPin.GetBuffer(0),16);

    memcpy(UpuidDlg.oldUserPin,Uid.GetBuffer(0),16);

   
    UpuidDlg.DoModal();
	
	UpdateData(FALSE);
	
}

HBRUSH CAboutDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if(::GetDlgCtrlID(pWnd->m_hWnd) ==IDC_STATIC5 )
	{
		pDC->SetTextColor(RGB(195,0,0));
	}
	if(::GetDlgCtrlID(pWnd->m_hWnd) ==IDC_STATIC6 )
	{
		pDC->SetTextColor(RGB(195,0,0));
	}
   	

	// TODO: Return a different brush if the default is not desired
	return hbr;
}

HBRUSH CSetSoPinDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CDialog::OnCtlColor(pDC, pWnd, nCtlColor);
	if(::GetDlgCtrlID(pWnd->m_hWnd) ==IDC_STATICWARING )
	{
		pDC->SetTextColor(RGB(255,0,0));
	}
	return hbr;
}

void CSetSoPinDlg::OnChangeOldpid() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnChangeOlduid() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnChangeNewuid() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnChangeSopinSeed() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnChangeEditupinnum() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnCheckpidflg() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnChecksopinflg() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnCheckuserpin() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CSetSoPinDlg::OnCheckreadwflg() 
{
	b_newUserPin=TRUE;
	b_pidSeed=TRUE;
	b_sopinSeed=TRUE;
	b_num=TRUE;
	b_all=FALSE;
	UpdateData(TRUE);
	if((m_oldpid.GetLength()!=8)||(m_olduid.GetLength()!=16)||m_oldpin.GetLength()!=16)
		b_all=FALSE;
	else
		b_all=TRUE;
	
	if(m_upinflg)
	{
		if(16!=m_newupin.GetLength())
			b_newUserPin=FALSE;
		else
			b_newUserPin=TRUE;
	}
	if(m_pidflg)
	{
		if((0==m_seed.GetLength())||(m_seed.GetLength()>51))
			b_pidSeed=FALSE;
		else
			b_pidSeed=TRUE;
	}
	if(m_sopinflg)
	{
		if((0==m_SopinSeed.GetLength())||(m_SopinSeed.GetLength()>51))
			b_sopinSeed=FALSE;
		else
			b_sopinSeed=TRUE;
	}
	if(m_readwflg)
	{
		if((GetDlgItemInt(IDC_EDITSOPINNUM)>15)||(GetDlgItemInt(IDC_EDITSOPINNUM)<0)||(GetDlgItemInt(IDC_EDITUPINNUM)>15)||(GetDlgItemInt(IDC_EDITUPINNUM)<0))
			b_num=FALSE;
		else
			b_num=TRUE;
	}
	
	if((!b_all)||(!b_newUserPin)||(!b_pidSeed)||(!b_sopinSeed)||(!b_num))
		m_btnSet.EnableWindow(FALSE);
	else
		m_btnSet.EnableWindow(TRUE);
	UpdateData(FALSE);
}
