#if !defined(AFX_UPDATAUIDDLG_H__CF3DD51F_8333_4208_B7B1_C6EC765852CB__INCLUDED_)
#define AFX_UPDATAUIDDLG_H__CF3DD51F_8333_4208_B7B1_C6EC765852CB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UpdataUidDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CUpdataUidDlg dialog

class CUpdataUidDlg : public CDialog
{
// Construction
public:
	CUpdataUidDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CUpdataUidDlg)
	enum { IDD = IDD_DIALOGUPDATAUID };
	CButton	m_updataB;
	CString	m_newpin1;
	CString	m_newpin2;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUpdataUidDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation

	public :
		unsigned char longPid[8];     //Ӳ��PID
        char          chSoPin[17];    //�����û���
		unsigned char newUserPin[16]; //�û���
		unsigned char oldUserPin[16]; //�û���
		ET_HANDLE hET99;              //ET99���
protected:

	// Generated message map functions
	//{{AFX_MSG(CUpdataUidDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnButupdatauid();
	afx_msg void OnChangeEditnewpin1();
	afx_msg void OnChangeEditnewpin2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UPDATAUIDDLG_H__CF3DD51F_8333_4208_B7B1_C6EC765852CB__INCLUDED_)
