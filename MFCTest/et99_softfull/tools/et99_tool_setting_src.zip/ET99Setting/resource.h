//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SetSoPin.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SETSOPIN_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_DIALOGUPDATAUID             129
#define EDIT_PID                        1000
#define EDIT_OLDPID                     1000
#define EDIT_OLDSOPIN                   1001
#define BUTTON_SET                      1002
#define BUTTON_EXIT                     1003
#define EDIT_SEED                       1004
#define EDIT_NEWSOPIN                   1005
#define BUTTON_RESET                    1006
#define EDIT_OLDUID                     1007
#define EDIT_NEWPID                     1008
#define EDIT_NEWUID                     1009
#define IDC_EDITSOPINNUM                1010
#define IDC_EDITUPINNUM                 1011
#define IDC_BUTHelp                     1012
#define IDC_BUTUPDATAUID                1013
#define IDC_BUTHOISTRY                  1013
#define IDC_EDITNEWPIN1                 1014
#define BUTTON_RESET2                   1014
#define IDC_EDITNEWPIN2                 1015
#define EDIT_SOPIN_SEED                 1015
#define IDC_CHECKREADW                  1016
#define IDC_CHECKPIDFLG                 1017
#define IDC_CHECKSOPINFLG               1018
#define IDC_STATIC5                     1018
#define IDC_CHECKREADWFLG               1019
#define IDC_STATIC6                     1019
#define IDC_CHECKUSERPIN                1020
#define IDC_STATIC7                     1020
#define IDC_STATICWARING                1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
