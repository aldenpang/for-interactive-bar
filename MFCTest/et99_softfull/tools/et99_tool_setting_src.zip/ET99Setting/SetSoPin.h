// SetSoPin.h : main header file for the SETSOPIN application
//

#if !defined(AFX_SETSOPIN_H__6B6C3AD3_D2EA_41CE_B581_8571932D1402__INCLUDED_)
#define AFX_SETSOPIN_H__6B6C3AD3_D2EA_41CE_B581_8571932D1402__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CSetSoPinApp:
// See SetSoPin.cpp for the implementation of this class
//

class CSetSoPinApp : public CWinApp
{
public:
	CSetSoPinApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetSoPinApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSetSoPinApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETSOPIN_H__6B6C3AD3_D2EA_41CE_B581_8571932D1402__INCLUDED_)
