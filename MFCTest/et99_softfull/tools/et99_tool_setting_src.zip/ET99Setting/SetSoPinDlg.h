// SetSoPinDlg.h : header file
//

#if !defined(AFX_SETSOPINDLG_H__84BB219F_9CC4_4EEC_8765_70F01A0F4B8A__INCLUDED_)
#define AFX_SETSOPINDLG_H__84BB219F_9CC4_4EEC_8765_70F01A0F4B8A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSetSoPinDlg dialog

#include "Fileini.h"

class CSetSoPinDlg : public CDialog
{
// Construction
public:
	CSetSoPinDlg(CWnd* pParent = NULL);	// standard constructor
        BOOL OpenDevice();
// Dialog Data
	//{{AFX_DATA(CSetSoPinDlg)
	enum { IDD = IDD_SETSOPIN_DIALOG };
	CButton m_btnSet;
	CString	m_pid;
	CString	m_oldpin;
	BOOL	m_dowhile;
	CString	m_olduid;
	CString	m_sopinnum;
	CString	m_upinnum;
	BOOL	m_readw;
	BOOL	m_pidflg;
	BOOL	m_readwflg;
	BOOL	m_sopinflg;
	BOOL	m_upinflg;
	CString	m_newupin;
	CString	m_seed;
	CString	m_newpid;
	CString	m_newsopin;
	CString	m_oldpid;
	CString	m_SopinSeed;
	//}}AFX_DATA

public:
	BOOL b_newUserPin;
	BOOL b_pidSeed;
	BOOL b_sopinSeed;
	BOOL b_num;
	BOOL b_all;

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetSoPinDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

	private:
		CString OldSoPin;
		CString Pid;
		CString Seed;
        CString Uid;
		CString NewUid;
		unsigned char longPid[8];     //Ӳ��PID
		
		ET_HANDLE hET99;              //���	
		
		
		CFileini fileini;             //INI�ļ���
// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSetSoPinDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnSet();
	afx_msg void OnChangeOldsopin();
	afx_msg void OnChangeSeed();
	virtual void OnOK();
	afx_msg void OnReset();
	afx_msg void OnButUpdataUid();
	afx_msg void OnChangeEditsopinnum();
	afx_msg void OnButhoistry();
	afx_msg void OnUpUpin();
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnChangeOldpid();
	afx_msg void OnChangeOlduid();
	afx_msg void OnChangeNewuid();
	afx_msg void OnChangeSopinSeed();
	afx_msg void OnChangeEditupinnum();
	afx_msg void OnCheckpidflg();
	afx_msg void OnChecksopinflg();
	afx_msg void OnCheckuserpin();
	afx_msg void OnCheckreadwflg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETSOPINDLG_H__84BB219F_9CC4_4EEC_8765_70F01A0F4B8A__INCLUDED_)
