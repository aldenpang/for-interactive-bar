// UpdataUidDlg.cpp : implementation file
//

#include "stdafx.h"
#include "SetSoPin.h"
#include "UpdataUidDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CUpdataUidDlg dialog


CUpdataUidDlg::CUpdataUidDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUpdataUidDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CUpdataUidDlg)
	m_newpin1 = _T("");
	m_newpin2 = _T("");
	//}}AFX_DATA_INIT
}


void CUpdataUidDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CUpdataUidDlg)
	DDX_Control(pDX, IDC_BUTUPDATAUID, m_updataB);
	DDX_Text(pDX, IDC_EDITNEWPIN1, m_newpin1);
	DDX_Text(pDX, IDC_EDITNEWPIN2, m_newpin2);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CUpdataUidDlg, CDialog)
	//{{AFX_MSG_MAP(CUpdataUidDlg)
	ON_BN_CLICKED(IDC_BUTUPDATAUID, OnButupdatauid)
	ON_EN_CHANGE(IDC_EDITNEWPIN1, OnChangeEditnewpin1)
	ON_EN_CHANGE(IDC_EDITNEWPIN2, OnChangeEditnewpin2)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CUpdataUidDlg message handlers

BOOL CUpdataUidDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	int tokenCount;

	unsigned long ret = ET_SUCCESS;

    ret = et_FindToken(longPid,&tokenCount);

	if(ET_SUCCESS!=ret)
	{
		MessageBox("�Ҳ���ָ����ET99!","UpUserPIN",MB_OK|MB_ICONSTOP);
		OnCancel();	
		return FALSE;
	}
	else
	{
		if(1!=tokenCount)
		{
			MessageBox("�ҵ�ָ����ET99��ֹ1��!","UpUserPIN",MB_OK|MB_ICONSTOP);
			OnCancel();
			return FALSE;
		}
	}

	ret = et_OpenToken(&hET99,longPid,1);
	if(ET_SUCCESS!=ret)
	{
		MessageBox("��ET99ʧ��!","UpUserPIN",MB_OK|MB_ICONSTOP);
		OnCancel();
		return FALSE;
	}

	/*ret = et_Verify(hET99,1,(unsigned char *)chSoPin);

	if(ET_SUCCESS!=ret)
	{
		MessageBox("�����û�PIN�����!","UpUserPIN",MB_OK|MB_ICONSTOP);
		et_CloseToken(hET99);
		OnCancel();
		return FALSE;
	}*/	

	ret = et_Verify(hET99,ET_VERIFY_USERPIN,oldUserPin);
	if(ET_SUCCESS!=ret)
	{
		MessageBox("�û�PIN�����!","UpUserPIN",MB_OK|MB_ICONSTOP);		
		et_CloseToken(hET99);
		OnCancel();
		return FALSE;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CUpdataUidDlg::OnButupdatauid() 
{
  	UpdateData(TRUE);
   	


	if(m_newpin1.IsEmpty() || m_newpin2.IsEmpty())
	{
		AfxMessageBox("�������µ��û�PID��!");
		return;
	}

	if(m_newpin1!=m_newpin2)
	{
	    m_newpin1.Empty(); m_newpin2.Empty();
		AfxMessageBox("����������û�PID�벻һ��!");
		UpdateData(FALSE);
		return ;
	}
    
	unsigned long ret = ET_SUCCESS;


	memcpy(newUserPin,m_newpin1.GetBuffer(0),16);

	ret = et_ChangeUserPIN(hET99,oldUserPin,newUserPin);
	
	if(ET_SUCCESS!=ret)
	{
		if(ret == ET_NOT_SET_PID)
			MessageBox("�㻹û���������ET99��PID!","ChangeUserPin",MB_OK|MB_ICONSTOP);
		else
			MessageBox("�ı��û�PIN�����!","ChangeUserPin",MB_OK|MB_ICONSTOP);
		et_CloseToken(hET99);
		OnOK();
		return;
	}
	

	MessageBox("�ı��û�PIN��ɹ�!","ChangeUserPin",MB_OK);
	et_CloseToken(hET99);
	
	OnOK();
}

void CUpdataUidDlg::OnChangeEditnewpin1() 
{
	GetDlgItemText(IDC_EDITNEWPIN1,m_newpin1);
	GetDlgItemText(IDC_EDITNEWPIN2,m_newpin2);
	if((16!=m_newpin1.GetLength())||(16!=m_newpin2.GetLength())||(m_newpin1!=m_newpin2))
		m_updataB.EnableWindow(FALSE);
	else
		m_updataB.EnableWindow(TRUE);
	
}

void CUpdataUidDlg::OnChangeEditnewpin2() 
{
	GetDlgItemText(IDC_EDITNEWPIN1,m_newpin1);
	GetDlgItemText(IDC_EDITNEWPIN2,m_newpin2);
	if((16!=m_newpin1.GetLength())||(16!=m_newpin2.GetLength())||(m_newpin1!=m_newpin2))
		m_updataB.EnableWindow(FALSE);
	else
		m_updataB.EnableWindow(TRUE);
	
}
