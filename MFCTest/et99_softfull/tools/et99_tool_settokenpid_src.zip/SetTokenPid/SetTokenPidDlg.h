// SetTokenPidDlg.h : header file
//

#if !defined(AFX_SETTokenPidDLG_H__84BB219F_9CC4_4EEC_8765_70F01A0F4B8A__INCLUDED_)
#define AFX_SETTokenPidDLG_H__84BB219F_9CC4_4EEC_8765_70F01A0F4B8A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSetTokenPidDlg dialog

class CSetTokenPidDlg : public CDialog
{
// Construction
public:
	CSetTokenPidDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSetTokenPidDlg)
	enum { IDD = IDD_SETTOKENPID_DIALOG };
	CButton m_btnSet;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetTokenPidDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

	private:
		CString OldSoPin;
		CString Pid;
		CString Seed;

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSetTokenPidDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnSet();
	afx_msg void OnChangePid();
	afx_msg void OnChangeOldsopin();
	afx_msg void OnChangeSeed();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETTokenPidDLG_H__84BB219F_9CC4_4EEC_8765_70F01A0F4B8A__INCLUDED_)
