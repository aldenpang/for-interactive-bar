// SetupTokenDlg.h : header file
//

#if !defined(AFX_SETUPTOKENDLG_H__22054680_E433_4C34_9BD9_092008470968__INCLUDED_)
#define AFX_SETUPTOKENDLG_H__22054680_E433_4C34_9BD9_092008470968__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CSetupTokenDlg dialog

class CSetupTokenDlg : public CDialog
{
// Construction
public:
	CSetupTokenDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSetupTokenDlg)
	enum { IDD = IDD_SETUPTOKEN_DIALOG };
	CButton m_btnSet;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSetupTokenDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

private:
	CString SoPin;
	CString Pid;
	CString SoPinRetry;
	CString UserPinRetry;
	CString ReadOnly;

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSetupTokenDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnExit();
	afx_msg void OnButtonSet();
	afx_msg void OnChangeEditPid();
	afx_msg void OnChangeEditSopin();
	afx_msg void OnChangeEditSopinRetry();
	afx_msg void OnChangeEditUserpinRetry();
	afx_msg void OnChangeEditReadOnly();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SETUPTOKENDLG_H__22054680_E433_4C34_9BD9_092008470968__INCLUDED_)
