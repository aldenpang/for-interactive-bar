// ET99AspInitDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ET99AspInit.h"
#include "ET99AspInitDlg.h"
#include "resource.h"

#define DMEO_TOKEN  0x1
#define DMEO_KEY    0x1

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

unsigned char i2a(char i,bool hi)
{
	if(hi)
	{
		i = i>>4;
		i&=0x0F;
	}
	else
		i&=0x0F;
	if(i>9)
	{
		return ('A'+(i-10));
	}
	return ('0'+i);
}
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CET99AspInitDlg dialog

CET99AspInitDlg::CET99AspInitDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CET99AspInitDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CET99AspInitDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CET99AspInitDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CET99AspInitDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CET99AspInitDlg, CDialog)
	//{{AFX_MSG_MAP(CET99AspInitDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CET99AspInitDlg message handlers

BOOL CET99AspInitDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	ZeroMemory(&m_sn,sizeof(char));
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CET99AspInitDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CET99AspInitDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CET99AspInitDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

// Format the ET99 error code to a string.
char* FormatErrMsg(ET_STATUS status)
{
    switch( status )
    {	
        case ET_SUCCESS:
            return ("");
        case ET_ACCESS_DENY:
            return ("Error: access denied, have not enough right!");
        case ET_COMMUNICATIONS_ERROR:
            return ("Error : have not open the device");
        case ET_INVALID_PARAMETER:
            return ("Error : Invalid Parameter!.");
        case ET_NOT_SET_PID:
            return ("Error : have not set PID!");
        case ET_UNIT_NOT_FOUND: 
            return ("Error : open the device fail!");
        default: 
            return ("Error : An unknown error occurred.");
    }
} // End of FormatErrMsg().

void CET99AspInitDlg::OnOK() 
{
	CString strInfo;

	//////////////////////////////////////////////////////////////////////////
	// Get the necessary information to create the KEY files.

//	CString strUserName;
	CString strPassword;
	CString strCnfrmPswd;
	CString strPID;
	CString userPin;
	CString strTempUN;
	CString strTempPW;
	unsigned char longPID[8];

//	GetDlgItemText(IDC_EDIT_USERNAME,strUserName);
	GetDlgItemText(IDC_EDIT_PSWD,strPassword);
	GetDlgItemText(IDC_EDIT_CNFRM_PSWD,strCnfrmPswd);
	GetDlgItemText(IDC_EDIT_PID,strPID);
	GetDlgItemText(IDC_EDIT_USERPIN,userPin);
	memcpy(longPID,strPID.GetBuffer(0),8);
	//sscanf(strPID.GetBuffer(0),"%lx",&longPID);

	if (lstrcmpi(strPassword,strCnfrmPswd) != 0)
	{
		AfxMessageBox("The password you input are not same.");
		return;
	}

	if (strPassword.IsEmpty() || strCnfrmPswd.IsEmpty())
	{
		AfxMessageBox("You must gave me enough information to create KEY file.");
		return;
	}

	//////////////////////////////////////////////////////////////////////////
	// Software-compute the MD5_HMAC and create context of key files.
	unsigned char pucKey[32];
	unsigned char pucDigest[16];

	MD5_HMAC(
		NULL,
		0,
		(unsigned char*)(LPCSTR)strPassword,
		strPassword.GetLength(),
		pucKey,
		pucDigest
		);

	//////////////////////////////////////////////////////////////////////////
	// ET99 operation.
	ET_STATUS ET99Ret;
	ET_HANDLE ET99Handle;
	int count=0;

	// Find ET99.
	ET99Ret = et_FindToken(longPID,&count);
	if (count ==0)
	{
		AfxMessageBox("not find any ET99");
		return;
	}
	// Open device.
	if (ET_SUCCESS == ET99Ret)
	{
		ET99Ret = et_OpenToken(&ET99Handle,longPID,DMEO_TOKEN);
	}
	if(ET_SUCCESS!=ET99Ret)
	{
		strInfo.Format("Initialize ET99 failed.\n\n%s",FormatErrMsg(ET99Ret));
		AfxMessageBox(strInfo);
	}
	//verify user pin
	ET99Ret = et_Verify(ET99Handle,ET_VERIFY_USERPIN,(unsigned char *)userPin.GetBuffer(0));
	if(ET_SUCCESS!=ET99Ret)
	{
		et_CloseToken(ET99Handle);
		strInfo.Format("Initialize ET99 failed.\n\n%s",FormatErrMsg(ET99Ret));
		AfxMessageBox(strInfo);
		return;
	}
	
	//add by Zhu Yangsheng 
	//date:2003/5/26
	//purpose:Get the token sn to insert user.txt
	unsigned char sn[8]={0};
	ET99Ret = et_GetSN(ET99Handle,(unsigned char*)sn);
	//m_sn = {0,};
	//sprintf(m_sn, "%08X%08X", sn[1], sn[0]);
	for(int i=0;i<8;i++)
	{
		m_sn[2*i] = i2a((char)sn[i],true);
		m_sn[2*i+1] = i2a((char)sn[i],false);
	}
	m_sn[16]='\0';

	if (ET_SUCCESS != ET99Ret)
	{
		et_CloseToken(ET99Handle);
		strInfo.Format(
			"Initialize ET99 failed.\n\n%s",
			FormatErrMsg(ET99Ret));
		AfxMessageBox(strInfo);
		return;
	}
	//set key
	ET99Ret = et_SetKey(ET99Handle,DMEO_KEY,pucKey);
	if(ET_SUCCESS != ET99Ret)
	{
		et_CloseToken(ET99Handle);
		strInfo.Format(
			"Initialize ET99 failed.\n\n%s",
			FormatErrMsg(ET99Ret));
		AfxMessageBox(strInfo);
		return;
	}
	else
	{
		::MessageBox(NULL,"OK! ET99 now initialized!\n\nYou can use it to logon the demo ASP site.","Successful",MB_OK|MB_ICONASTERISK);
	}

	ET99Ret = et_CloseToken(ET99Handle);

		//////////////////////////////////////////////////////////////////////////
	// File operation.

	CStdioFile fUser;
	CFileException ex;

	// Create the file "user.txt" to write.

	if (!fUser.Open("user.txt",
			CFile::modeReadWrite |
			CFile::modeNoTruncate |
			CFile::modeCreate,
			&ex))
	{
		TCHAR szError[1024];
		ex.GetErrorMessage(szError, 1024);
		strInfo.Format("Couldn't open data file : %s",szError);
		AfxMessageBox(strInfo);
		return;
	}

	// First search whether the username had exists.
	BOOL bExists = FALSE;
	BOOL bRead = TRUE;
	while (bRead)
	{
		bRead = fUser.ReadString(strTempUN);
		if (bRead)
		{
			bRead = fUser.ReadString(strTempPW);
		}
		CString strUserName = m_sn;
		if (strTempUN == strUserName)
		{
			bExists = TRUE;
		}

	}

	if (!bExists)
	{
		fUser.WriteString(m_sn);
		//here we should write sn
		fUser.WriteString("\n");
		fUser.WriteString(strPassword);//,strPassword.GetLength());
		fUser.WriteString("\n");
	}
	else
	{
		AfxMessageBox("Sorry, the user had exists.",MB_OK | MB_ICONSTOP);
		fUser.Close();
		return;
	}


	fUser.Close();

	// Call the CDialog::OnOK() to close the window
	// and exit the demonstrator program.
	CDialog::OnOK();
}
