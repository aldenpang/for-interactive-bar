// ET99AspInit.h : main header file for the ET99ASPINIT application
//

#if !defined(AFX_ET99ASPINIT_H__821BC5D6_E15F_4A9D_BCBE_A83F298D1A24__INCLUDED_)
#define AFX_ET99ASPINIT_H__821BC5D6_E15F_4A9D_BCBE_A83F298D1A24__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CET99AspInitApp:
// See ET99AspInit.cpp for the implementation of this class
//

class CET99AspInitApp : public CWinApp
{
public:
	CET99AspInitApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CET99AspInitApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CET99AspInitApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ET99ASPINIT_H__821BC5D6_E15F_4A9D_BCBE_A83F298D1A24__INCLUDED_)
