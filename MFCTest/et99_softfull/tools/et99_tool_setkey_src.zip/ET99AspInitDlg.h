// ET99AspInitDlg.h : header file
//

#if !defined(AFX_ET99ASPINITDLG_H__48F2D7B7_1FDA_4601_9D7C_777003590987__INCLUDED_)
#define AFX_ET99ASPINITDLG_H__48F2D7B7_1FDA_4601_9D7C_777003590987__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../../../include/FT_ET99_API.h"

char* FormatErrMsg(ET_STATUS status);

/////////////////////////////////////////////////////////////////////////////
// CET99AspInitDlg dialog

class CET99AspInitDlg : public CDialog
{
// Construction
public:
	CET99AspInitDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CET99AspInitDlg)
	enum { IDD = IDD_ET99ASPINIT_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CET99AspInitDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	char m_sn[17];
	// Generated message map functions
	//{{AFX_MSG(CET99AspInitDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ET99ASPINITDLG_H__48F2D7B7_1FDA_4601_9D7C_777003590987__INCLUDED_)
