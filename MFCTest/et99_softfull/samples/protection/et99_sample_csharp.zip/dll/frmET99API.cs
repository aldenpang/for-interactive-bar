﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Runtime.InteropServices;

namespace ET99Tools
{
    public partial class frmET99API : Form
    {
        /// <summary>
        /// 当前打开设备的句柄
        /// </summary>
        private IntPtr hHandle;

        public frmET99API()
        {
            InitializeComponent();
        }

        //查找设备
        private void btnFind_Click(object sender, EventArgs e)
        {
            string strPID = txtOldPid.Text;
            byte[] bytPID = new byte[8];
            int count = 0;

            if(strPID.Length!=8)
            {
                MessageBox.Show("请输入有效的八位PID！");
                return;
            }

            bytPID = System.Text.Encoding.ASCII.GetBytes(strPID);
            uint result = ET99_API.et_FindToken(bytPID, out count);
            if ( result== ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("找到 " + count.ToString() +" 个加密狗设备！");
            }
            else
            {
                MessageBox.Show("查找加密狗失败！请确认您的PID正确。\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //打开设备
        private void btnOpen_Click(object sender, EventArgs e)
        {
            int index = 1;
            string strPID = txtOldPid.Text;
            byte[] bytPID = new byte[8];

            if (strPID.Length != 8)
            {
                MessageBox.Show("请输入有效的八位PID！");
                return;
            }

            bytPID = System.Text.Encoding.ASCII.GetBytes(strPID);
            uint result = ET99_API.et_OpenToken(ref hHandle, bytPID, index);
            if (result == ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("成功打开第一个加密狗设备！");
                btnOpen.Enabled = false;
                btnClose.Enabled = true;
            }
            else
            {
                MessageBox.Show("打开加密狗失败！请确认您的PID正确。\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //关闭设备
        private void btnClose_Click(object sender, EventArgs e)
        {
            uint result = ET99_API.et_CloseToken(hHandle);
            if (result == ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("成功关闭第一个加密狗设备！");
                btnOpen.Enabled = true;
                btnClose.Enabled = false;
                hHandle = System.IntPtr.Zero;
            }
            else
            {
                MessageBox.Show("关闭加密狗失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //用户身份认证
        private void btnVerify_Click(object sender, EventArgs e)
        {
            string strPIN = txtPin.Text;
            byte[] bytPIN = new byte[16];
            int flag = ET99_API.ET_VERIFY_SOPIN;

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            if (strPIN.Length != 16)
            {
                MessageBox.Show("请输入有效的16位密码！");
                return;
            }
            if (rdoSoPin.Checked)
            {
                flag = ET99_API.ET_VERIFY_SOPIN;
            }
            else
            {
                flag = ET99_API.ET_VERIFY_USERPIN;
            }

            bytPIN = System.Text.Encoding.ASCII.GetBytes(strPIN);

            uint result = ET99_API.et_Verify(hHandle, flag, bytPIN);
            if (result == ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("认证成功！进入 " + (flag==ET99_API.ET_VERIFY_SOPIN?"超级用户":"普通用户") + " 状态。" );
            }
            else
            {
                MessageBox.Show("认证失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //修改普通用户的PIN
        private void btnModifyUserPin_Click(object sender, EventArgs e)
        {
            string strOldUserPin = txtOldUserPin.Text;
            byte[] bytOldUserPin = new byte[16];
            string strNewUserPin = txtNewUserPin.Text;
            byte[] bytNewUserPin = new byte[16];

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            if (strOldUserPin.Length != 16)
            {
                MessageBox.Show("请输入有效的16位旧PID！");
                txtOldUserPin.Focus();
                return;
            }
            if (strNewUserPin.Length != 16)
            {
                MessageBox.Show("请输入有效的16位新PID！");
                txtNewUserPin.Focus();
                return;
            }

            bytOldUserPin = System.Text.Encoding.ASCII.GetBytes(strOldUserPin);
            bytNewUserPin = System.Text.Encoding.ASCII.GetBytes(strNewUserPin);
            uint result = ET99_API.et_ChangeUserPIN(hHandle, bytOldUserPin, bytNewUserPin);
            if (result == ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("普通用户PIN修改成功！进入普通用户状态。");
            }
            else
            {
                MessageBox.Show("普通用户PIN修改失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //获取硬件SN
        private void btnGetSN_Click(object sender, EventArgs e)
        {
            byte[] bytSN = new byte[8];

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            uint result = ET99_API.et_GetSN(hHandle, bytSN);
            if (result == ET99_API.ET_SUCCESS)
            {
                //显示获取到的SN到文本框中
                string strSN = "";
                for (int i = 0; i < 8; ++i)
                {
                    strSN += string.Format("{0:X2}", bytSN[i]);
                }
                txtSN.Text = strSN;

                MessageBox.Show("获取成功！");
            }
            else
            {
                MessageBox.Show("获取失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //重置安全状态
        private void btnResetStatus_Click(object sender, EventArgs e)
        {
            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            uint result = ET99_API.et_ResetSecurityState(hHandle);
            if (result == ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("重置安全状态成功！现在进入匿名状态。");
            }
            else
            {
                MessageBox.Show("重置安全状态失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //产生新的PID
        private void btnGenPID_Click(object sender, EventArgs e)
        {
            string strSeed = txtSeed.Text;
            byte[] bytSeed;
            int iSeedLen = strSeed.Length;

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            if (strSeed.Length <=0)
            {
                MessageBox.Show("请输入有效的种子！");
                txtSeed.Focus();
                return;
            }

            StringBuilder strNewPID = new StringBuilder();
            bytSeed = System.Text.Encoding.ASCII.GetBytes(strSeed);
            uint result = ET99_API.et_GenPID(hHandle, iSeedLen, bytSeed, strNewPID);
            
            if (result == ET99_API.ET_SUCCESS)
            {
                txtNewPID.Text = strNewPID.ToString().Trim().Substring(0,8);
                Clipboard.SetDataObject(txtNewPID.Text);
                MessageBox.Show("成功写入新的PID到当前设备中！");
            }
            else
            {
                MessageBox.Show("写入新的PID到当前设备失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //产生新的超级用户PIN
        private void btnGenSoPin_Click(object sender, EventArgs e)
        {
            string strSeed = txtGenSoPinSeed.Text;
            byte[] bytSeed;
            StringBuilder strNewPIN = new StringBuilder(16);
            int iSeedLen = strSeed.Length;

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            if (strSeed.Length <= 0)
            {
                MessageBox.Show("请输入有效的种子！");
                txtGenSoPinSeed.Focus();
                return;
            }

            bytSeed = System.Text.Encoding.ASCII.GetBytes(strSeed);
            uint result = ET99_API.et_GenSOPIN(hHandle, iSeedLen, bytSeed, strNewPIN);
            if (result == ET99_API.ET_SUCCESS)
            {
                txtNewSoPin.Text = strNewPIN.ToString().Trim();
                MessageBox.Show("成功产生新的超级用户PIN！请牢记前16位。");
            }
            else
            {
                MessageBox.Show("产生新的超级用户PIN失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //重置普通用户PIN为 ffffffffffffffff
        private void btnResetUserPin_Click(object sender, EventArgs e)
        {
            string strSoPIN = txtSoPin.Text;
            byte[] bytPIN = new byte[16];

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            if (strSoPIN.Length != 16)
            {
                MessageBox.Show("请输入有效的16位密码！");
                txtSoPin.Focus();
                return;
            }

            bytPIN = System.Text.Encoding.ASCII.GetBytes(strSoPIN);

            uint result = ET99_API.et_ResetPIN(hHandle, bytPIN);
            if (result == ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("重置普通用户PIN为 ffffffffffffffff 成功！进入 超级用户 状态。");
            }
            else
            {
                MessageBox.Show("重置普通用户PIN失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //设置MD5校验密匙
        private void btnSetMd5Key_Click(object sender, EventArgs e)
        {
            int keyid = 1;
            string strMd5Key = txtMD5Key.Text;
            byte[] bytShortKey;

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }
            #region 数据验证
            if (strMd5Key.Length <=0)
            {
                MessageBox.Show("请输入有效的KEY！");
                txtMD5Key.Focus();
                return;
            }
            if (txtKeyID.Text.Length <= 0)
            { 
                MessageBox.Show("请输入正确的标志位！允许的取值范围1-8。");
                txtKeyID.Focus();
                return;               
            }
            if (!int.TryParse(txtKeyID.Text, out keyid))
            {
                MessageBox.Show("请输入正确的标志位！允许的取值范围1-8。");
                txtKeyID.Focus();
                return;
            }
            else
            {
                if (keyid < 0 && keyid > 9)
                {
                    MessageBox.Show("请输入正确的标志位！允许的取值范围1-8。");
                    txtKeyID.Focus();
                    return;     
                }
            }
            #endregion

            //生成需要写入的KEY
            bytShortKey = new byte[strMd5Key.Length];
            bytShortKey = System.Text.Encoding.ASCII.GetBytes(strMd5Key);

            byte[] randombuffer = new byte[51];
            byte keylen = byte.Parse(strMd5Key.Length.ToString());
            byte randomlen = 51;

            byte[] sbMd5Key = new byte[32];
            byte[] sbdigest = new byte[16];

            //第一个参数是随机数，在设置密钥时没有作用
            //第二个参数是随机数长度，在设置密钥时没有作用
            //第三个参数是分配给客户的密钥
            //第四个参数是分配给客户的密钥的长度
            //第五个参数是返回的32字节的密钥，用于存到锁内
            //第六个参数在设置密钥时没有作用
            uint result = ET99_API.MD5_HMAC(randombuffer, randomlen,bytShortKey, keylen,sbMd5Key,sbdigest);


            result = ET99_API.et_SetKey(hHandle, keyid, sbMd5Key);
            if (result == ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("设置MD5校验密匙成功！");
            }
            else
            {
                MessageBox.Show("设置MD5校验密匙失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }

        }


        //设置设备参数
        private void btnSetup_Click(object sender, EventArgs e)
        {
            string  strSoPinRetries= txtSopinRetries.Text;
            string strUserPinRetries = txtUserpinRetries.Text;

            byte bytUserReadOnly = ET99_API.ET_USER_WRITE_READ;
            byte bytSoPinRetries = 0;
            byte bytUserPinRetries = 0;
            byte bytBack = 0;

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            if (!byte.TryParse(strSoPinRetries,out bytSoPinRetries))
            {
                MessageBox.Show("请输入有效的超级用户PIN重试次数！");
                txtSopinRetries.Focus();
                return;
            }
            if (!byte.TryParse(strUserPinRetries, out bytUserPinRetries))
            {
                MessageBox.Show("请输入有效的普通用户PIN重试次数！");
                txtSopinRetries.Focus();
                return;
            }

            if (rdoWriteRead.Checked)
            {
                bytUserReadOnly = ET99_API.ET_USER_WRITE_READ;
            }
            else
            {
                bytUserReadOnly = ET99_API.ET_USER_READ_ONLY;
            }

            uint result = ET99_API.et_SetupToken(hHandle, bytSoPinRetries, bytUserPinRetries, bytUserReadOnly, bytBack);
            if (result == ET99_API.ET_SUCCESS)
            {
                MessageBox.Show("设备参数设置成功！");
            }
            else
            {
                MessageBox.Show("设备参数设置失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //打开或关闭LED
        private void btnLED_Click(object sender, EventArgs e)
        {
            string strSoPIN = txtSoPin.Text;
            byte[] bytPIN = new byte[16];

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            uint result ;
            if (btnLED.Tag.ToString() == "on")
            {
                result = ET99_API.et_TurnOffLED(hHandle);
            }
            else
            {
                result = ET99_API.et_TurnOnLED(hHandle);
            }
            if (result == ET99_API.ET_SUCCESS)
            {
                if (btnLED.Tag.ToString() == "on")
                {
                    btnLED.Tag = "off";
                }
                else
                {
                    btnLED.Tag = "on";
                }
                MessageBox.Show("操作成功！");
            }
            else
            {
                MessageBox.Show("操作失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        //使用设备进行MD5_HMAC验证计算
        private void btnVerifyMd5HMAC_Click(object sender, EventArgs e)
        {
            uint result = 0;
            string strRandomCode  = txtVerifyRandom.Text;
            byte[] bytRandomCode;
            byte[] bytDigest = new byte[16];

            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }
            if(strRandomCode.Length<=0 && strRandomCode.Length>51)
            {
                MessageBox.Show("请输入有效的随机数！允许的长度为：1-51");
                txtVerifyRandom.Focus();
                return;               
            }

            bytRandomCode = new byte[strRandomCode.Length];
            bytRandomCode = System.Text.Encoding.ASCII.GetBytes(strRandomCode);

            //服务器上软件计算
            String strMD5Key = txtMD5Key.Text;
            byte[] bytShortKey;
            bytShortKey = new byte[strMD5Key.Length];
            bytShortKey = System.Text.Encoding.ASCII.GetBytes(strMD5Key);
            byte keylen = byte.Parse(strMD5Key.Length.ToString());
            byte randomlen = byte.Parse(strRandomCode.Length.ToString());

            byte[] sbMd5Key = new byte[32];
            byte[] sbdigest = new byte[16];
            //第一个参数是随机数
            //第二个参数是随机数长度
            //第三个参数是分配给客户的密钥（应该从数据库中取出）
            //第四个参数是分配给客户的密钥的长度
            //第五个参数没有作用
            //第六个参数为软件计算的结果
            result = ET99_API.MD5_HMAC(bytRandomCode, randomlen, bytShortKey, keylen, sbMd5Key, sbdigest);
            if (result == ET99_API.ET_SUCCESS)
            {
                //显示获取到的SN到文本框中
                string strSoftDigest = "";
                for (int i = 0; i <16; ++i)
                {
                    strSoftDigest += string.Format("{0:X2}", sbdigest[i]);
                }
                softdigest.Text = strSoftDigest;


            }
            else
            {
                MessageBox.Show("操作失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
            
            
            //硬件中计算
            //第一个参数为设备的handle句柄
            //第二个参数为硬件中密钥索引
            //第三个参数为随机数长度
            //第四个参数为随机数
            //第五个参数为硬件中计算结果
            result = ET99_API.et_HMAC_MD5(hHandle, 1, strRandomCode.Length, bytRandomCode, bytDigest);
            if (result == ET99_API.ET_SUCCESS)
            {
                //显示获取到的SN到文本框中
                string strDigest = "";
                for (int i = 0; i <16; ++i)
                {
                    strDigest += string.Format("{0:X2}", bytDigest[i]);
                }
                txtVerifyResult.Text = strDigest;


            }
            else
            {
                MessageBox.Show("操作失败！\r\n\r\n错误：" + ET99_API.ShowResultText(result));
            }
        }

        private void btn_write_Click(object sender, EventArgs e)
        {
            
            
            
             byte[] zyn=new byte[16];
             
             string aaa = txt_write.Text.Trim();
             
             zyn = System.Text.Encoding.ASCII.GetBytes(aaa);

             byte[] bTemp = new byte[17];//一个新的数组，第一个字节存要读取的长度，后面是要写入的数据
             bTemp[0] = (byte)zyn.Length;
             for (int i = 0; i < zyn.Length; ++i)
             {
                 bTemp[i + 1] = zyn[i];
             }
             
            
     
            ushort len=0;//偏移

             if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            uint resultmess = ET99_API.et_Write(hHandle, len, zyn.Length + 1, bTemp);// 传入值

            if (resultmess == ET99_API.ET_SUCCESS)
            {
                
                MessageBox.Show("写入用户名成功！");
            }

            if (resultmess == ET99_API.ET_HARD_ERROR)
            {
                MessageBox.Show("硬件错误！");

            }
            if (resultmess == ET99_API.ET_ACCESS_DENY)
            {
                MessageBox.Show("权限不够！");

            }


        }

        private void btn_read_Click(object sender, EventArgs e)
        {
            //总是出错，完全清空
            ushort len = 0;//偏移
            if (hHandle == System.IntPtr.Zero)
            {
                MessageBox.Show("请先打开设备！");
                return;
            }

            byte[] readlen = new byte[1];
            byte[] zyn = new byte[16];


            uint resultmess = ET99_API.et_Read(hHandle, len, 1, readlen);//先读出第一个字节的数据长度到readlen中

            if (resultmess == ET99_API.ET_HARD_ERROR)
            {
                MessageBox.Show("硬件错误！");

            }
            if (resultmess == ET99_API.ET_ACCESS_DENY)
            {
                MessageBox.Show("权限不够！");

            }

            resultmess = ET99_API.et_Read(hHandle, (ushort)(len+1), readlen[0], zyn);//从第二个字节开始读取数据，读取数据
            if (resultmess == ET99_API.ET_SUCCESS)
            {

                MessageBox.Show("读取用户名成功！");
            }


            txt_read.Text = Encoding.ASCII.GetString(zyn);

        }

        private void btn_clear_Click(object sender, EventArgs e)
        {
            //总是出错，完全清空

            //就是将锁内的数据区全部写成0x00
            byte[] zerodata = new byte[50]; //1000字节每次写50个字节，循环20次
            uint resultmess = 0;
            int i = 0;

            for (i = 0; i < 50; ++i)
            {
                zerodata[i] = 0x00;
            }

            for (i = 0; i < 20; ++i)
            {
                resultmess = ET99_API.et_Write(hHandle, (ushort)(i * 50), 50, zerodata);
                if (resultmess != ET99_API.ET_SUCCESS)
                {
                    MessageBox.Show("失败！");
                    return;

                }
            }
            MessageBox.Show("成功！");

        }
    }
}
