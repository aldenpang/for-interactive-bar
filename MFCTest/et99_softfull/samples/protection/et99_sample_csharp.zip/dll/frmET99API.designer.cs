﻿namespace ET99Tools
{
    partial class frmET99API
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmET99API));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnOpen = new System.Windows.Forms.Button();
            this.txtOldPid = new System.Windows.Forms.TextBox();
            this.btnFind = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnGenPID = new System.Windows.Forms.Button();
            this.txtNewPID = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSeed = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnVerify = new System.Windows.Forms.Button();
            this.rdoSoPin = new System.Windows.Forms.RadioButton();
            this.rdoUserPin = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.txtPin = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.txtNewUserPin = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnModifyUserPin = new System.Windows.Forms.Button();
            this.txtOldUserPin = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.btnResetStatus = new System.Windows.Forms.Button();
            this.btnGetSN = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSN = new System.Windows.Forms.TextBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.btnGenSoPin = new System.Windows.Forms.Button();
            this.txtNewSoPin = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txtGenSoPinSeed = new System.Windows.Forms.TextBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.btnResetUserPin = new System.Windows.Forms.Button();
            this.txtSoPin = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.softdigest = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtVerifyResult = new System.Windows.Forms.TextBox();
            this.btnVerifyMd5HMAC = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.txtVerifyRandom = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtKeyID = new System.Windows.Forms.TextBox();
            this.btnSetMd5Key = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.txtMD5Key = new System.Windows.Forms.TextBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtUserpinRetries = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtSopinRetries = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnSetup = new System.Windows.Forms.Button();
            this.rdoWriteRead = new System.Windows.Forms.RadioButton();
            this.rdoReadOnly = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.btnLED = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.lab_write_read = new System.Windows.Forms.Label();
            this.btn_clear = new System.Windows.Forms.Button();
            this.btn_read = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txt_read = new System.Windows.Forms.TextBox();
            this.txt_write = new System.Windows.Forms.TextBox();
            this.btn_write = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.btnClose);
            this.groupBox1.Controls.Add(this.btnOpen);
            this.groupBox1.Controls.Add(this.txtOldPid);
            this.groupBox1.Controls.Add(this.btnFind);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(400, 58);
            this.groupBox1.TabIndex = 17;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "查找";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 4;
            this.label1.Text = "PID:";
            // 
            // btnClose
            // 
            this.btnClose.Enabled = false;
            this.btnClose.Location = new System.Drawing.Point(315, 20);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "关闭设备";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(234, 20);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(75, 23);
            this.btnOpen.TabIndex = 2;
            this.btnOpen.Text = "打开设备";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // txtOldPid
            // 
            this.txtOldPid.Location = new System.Drawing.Point(44, 20);
            this.txtOldPid.Name = "txtOldPid";
            this.txtOldPid.Size = new System.Drawing.Size(100, 21);
            this.txtOldPid.TabIndex = 1;
            this.txtOldPid.Text = "ffffffff";
            // 
            // btnFind
            // 
            this.btnFind.Location = new System.Drawing.Point(153, 20);
            this.btnFind.Name = "btnFind";
            this.btnFind.Size = new System.Drawing.Size(75, 23);
            this.btnFind.TabIndex = 0;
            this.btnFind.Text = "查找设备";
            this.btnFind.UseVisualStyleBackColor = true;
            this.btnFind.Click += new System.EventHandler(this.btnFind_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnGenPID);
            this.groupBox2.Controls.Add(this.txtNewPID);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtSeed);
            this.groupBox2.Location = new System.Drawing.Point(12, 296);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(400, 75);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "生成PID(超级用户权限)";
            // 
            // btnGenPID
            // 
            this.btnGenPID.Location = new System.Drawing.Point(268, 20);
            this.btnGenPID.Name = "btnGenPID";
            this.btnGenPID.Size = new System.Drawing.Size(113, 47);
            this.btnGenPID.TabIndex = 8;
            this.btnGenPID.Text = "写入新PID";
            this.btnGenPID.UseVisualStyleBackColor = true;
            this.btnGenPID.Click += new System.EventHandler(this.btnGenPID_Click);
            // 
            // txtNewPID
            // 
            this.txtNewPID.Location = new System.Drawing.Point(56, 46);
            this.txtNewPID.Name = "txtNewPID";
            this.txtNewPID.Size = new System.Drawing.Size(194, 21);
            this.txtNewPID.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 6;
            this.label3.Text = "新PID:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "种子:";
            // 
            // txtSeed
            // 
            this.txtSeed.Location = new System.Drawing.Point(56, 20);
            this.txtSeed.Name = "txtSeed";
            this.txtSeed.Size = new System.Drawing.Size(194, 21);
            this.txtSeed.TabIndex = 0;
            this.txtSeed.Text = "1234567";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnVerify);
            this.groupBox3.Controls.Add(this.rdoSoPin);
            this.groupBox3.Controls.Add(this.rdoUserPin);
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.txtPin);
            this.groupBox3.Controls.Add(this.label4);
            this.groupBox3.Location = new System.Drawing.Point(12, 76);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(400, 76);
            this.groupBox3.TabIndex = 19;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "身份认证";
            // 
            // btnVerify
            // 
            this.btnVerify.Location = new System.Drawing.Point(268, 14);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.Size = new System.Drawing.Size(113, 52);
            this.btnVerify.TabIndex = 12;
            this.btnVerify.Text = "Verify";
            this.btnVerify.UseVisualStyleBackColor = true;
            this.btnVerify.Click += new System.EventHandler(this.btnVerify_Click);
            // 
            // rdoSoPin
            // 
            this.rdoSoPin.AutoSize = true;
            this.rdoSoPin.Location = new System.Drawing.Point(83, 21);
            this.rdoSoPin.Name = "rdoSoPin";
            this.rdoSoPin.Size = new System.Drawing.Size(71, 16);
            this.rdoSoPin.TabIndex = 11;
            this.rdoSoPin.Text = "超级用户";
            this.rdoSoPin.UseVisualStyleBackColor = true;
            // 
            // rdoUserPin
            // 
            this.rdoUserPin.AutoSize = true;
            this.rdoUserPin.Checked = true;
            this.rdoUserPin.Location = new System.Drawing.Point(166, 21);
            this.rdoUserPin.Name = "rdoUserPin";
            this.rdoUserPin.Size = new System.Drawing.Size(71, 16);
            this.rdoUserPin.TabIndex = 10;
            this.rdoUserPin.TabStop = true;
            this.rdoUserPin.Text = "普通用户";
            this.rdoUserPin.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 21);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 12);
            this.label5.TabIndex = 9;
            this.label5.Text = "认证方式:";
            // 
            // txtPin
            // 
            this.txtPin.Location = new System.Drawing.Point(53, 45);
            this.txtPin.Name = "txtPin";
            this.txtPin.Size = new System.Drawing.Size(194, 21);
            this.txtPin.TabIndex = 8;
            this.txtPin.Text = "ffffffffffffffff";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 48);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 5;
            this.label4.Text = "PIN:";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtNewUserPin);
            this.groupBox4.Controls.Add(this.label6);
            this.groupBox4.Controls.Add(this.btnModifyUserPin);
            this.groupBox4.Controls.Add(this.txtOldUserPin);
            this.groupBox4.Controls.Add(this.label7);
            this.groupBox4.Location = new System.Drawing.Point(12, 158);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(400, 71);
            this.groupBox4.TabIndex = 20;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "修改用户PIN";
            // 
            // txtNewUserPin
            // 
            this.txtNewUserPin.Location = new System.Drawing.Point(53, 44);
            this.txtNewUserPin.Name = "txtNewUserPin";
            this.txtNewUserPin.Size = new System.Drawing.Size(194, 21);
            this.txtNewUserPin.TabIndex = 14;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 13;
            this.label6.Text = "新PIN:";
            // 
            // btnModifyUserPin
            // 
            this.btnModifyUserPin.Location = new System.Drawing.Point(268, 14);
            this.btnModifyUserPin.Name = "btnModifyUserPin";
            this.btnModifyUserPin.Size = new System.Drawing.Size(113, 45);
            this.btnModifyUserPin.TabIndex = 12;
            this.btnModifyUserPin.Text = "修改普通用户PIN";
            this.btnModifyUserPin.UseVisualStyleBackColor = true;
            this.btnModifyUserPin.Click += new System.EventHandler(this.btnModifyUserPin_Click);
            // 
            // txtOldUserPin
            // 
            this.txtOldUserPin.Location = new System.Drawing.Point(53, 20);
            this.txtOldUserPin.Name = "txtOldUserPin";
            this.txtOldUserPin.Size = new System.Drawing.Size(194, 21);
            this.txtOldUserPin.TabIndex = 8;
            this.txtOldUserPin.Text = "ffffffffffffffff";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 5;
            this.label7.Text = "旧PIN:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.btnResetStatus);
            this.groupBox5.Controls.Add(this.btnGetSN);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.txtSN);
            this.groupBox5.Location = new System.Drawing.Point(12, 235);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(400, 55);
            this.groupBox5.TabIndex = 21;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "重置安全状态/获取硬件SN编号";
            // 
            // btnResetStatus
            // 
            this.btnResetStatus.Location = new System.Drawing.Point(268, 18);
            this.btnResetStatus.Name = "btnResetStatus";
            this.btnResetStatus.Size = new System.Drawing.Size(113, 23);
            this.btnResetStatus.TabIndex = 9;
            this.btnResetStatus.Text = "重置安全状态";
            this.btnResetStatus.UseVisualStyleBackColor = true;
            this.btnResetStatus.Click += new System.EventHandler(this.btnResetStatus_Click);
            // 
            // btnGetSN
            // 
            this.btnGetSN.Location = new System.Drawing.Point(197, 18);
            this.btnGetSN.Name = "btnGetSN";
            this.btnGetSN.Size = new System.Drawing.Size(57, 23);
            this.btnGetSN.TabIndex = 8;
            this.btnGetSN.Text = "获取SN";
            this.btnGetSN.UseVisualStyleBackColor = true;
            this.btnGetSN.Click += new System.EventHandler(this.btnGetSN_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(23, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "SN:";
            // 
            // txtSN
            // 
            this.txtSN.Location = new System.Drawing.Point(56, 20);
            this.txtSN.Name = "txtSN";
            this.txtSN.Size = new System.Drawing.Size(135, 21);
            this.txtSN.TabIndex = 6;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.btnGenSoPin);
            this.groupBox6.Controls.Add(this.txtNewSoPin);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Controls.Add(this.label10);
            this.groupBox6.Controls.Add(this.txtGenSoPinSeed);
            this.groupBox6.Location = new System.Drawing.Point(439, 12);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(400, 75);
            this.groupBox6.TabIndex = 22;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "生成超级用户PIN(超级用户权限)";
            // 
            // btnGenSoPin
            // 
            this.btnGenSoPin.Location = new System.Drawing.Point(268, 20);
            this.btnGenSoPin.Name = "btnGenSoPin";
            this.btnGenSoPin.Size = new System.Drawing.Size(113, 47);
            this.btnGenSoPin.TabIndex = 8;
            this.btnGenSoPin.Text = "生成超级用户PIN";
            this.btnGenSoPin.UseVisualStyleBackColor = true;
            this.btnGenSoPin.Click += new System.EventHandler(this.btnGenSoPin_Click);
            // 
            // txtNewSoPin
            // 
            this.txtNewSoPin.Location = new System.Drawing.Point(56, 46);
            this.txtNewSoPin.Name = "txtNewSoPin";
            this.txtNewSoPin.Size = new System.Drawing.Size(194, 21);
            this.txtNewSoPin.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 49);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(41, 12);
            this.label9.TabIndex = 6;
            this.label9.Text = "新PIN:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 23);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 12);
            this.label10.TabIndex = 5;
            this.label10.Text = "种子:";
            // 
            // txtGenSoPinSeed
            // 
            this.txtGenSoPinSeed.Location = new System.Drawing.Point(56, 20);
            this.txtGenSoPinSeed.Name = "txtGenSoPinSeed";
            this.txtGenSoPinSeed.Size = new System.Drawing.Size(194, 21);
            this.txtGenSoPinSeed.TabIndex = 0;
            this.txtGenSoPinSeed.Text = "1234567";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.btnResetUserPin);
            this.groupBox7.Controls.Add(this.txtSoPin);
            this.groupBox7.Controls.Add(this.label12);
            this.groupBox7.Location = new System.Drawing.Point(439, 97);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(400, 71);
            this.groupBox7.TabIndex = 23;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "重置普通用户PIN（超级用户权限)";
            // 
            // btnResetUserPin
            // 
            this.btnResetUserPin.Location = new System.Drawing.Point(268, 14);
            this.btnResetUserPin.Name = "btnResetUserPin";
            this.btnResetUserPin.Size = new System.Drawing.Size(113, 45);
            this.btnResetUserPin.TabIndex = 12;
            this.btnResetUserPin.Text = "重置普通用户PIN";
            this.btnResetUserPin.UseVisualStyleBackColor = true;
            this.btnResetUserPin.Click += new System.EventHandler(this.btnResetUserPin_Click);
            // 
            // txtSoPin
            // 
            this.txtSoPin.Location = new System.Drawing.Point(56, 38);
            this.txtSoPin.Name = "txtSoPin";
            this.txtSoPin.Size = new System.Drawing.Size(194, 21);
            this.txtSoPin.TabIndex = 8;
            this.txtSoPin.Text = "ffffffffffffffff";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(9, 23);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 5;
            this.label12.Text = "超级用户PIN:";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.groupBox10);
            this.groupBox8.Controls.Add(this.label13);
            this.groupBox8.Controls.Add(this.txtKeyID);
            this.groupBox8.Controls.Add(this.btnSetMd5Key);
            this.groupBox8.Controls.Add(this.label11);
            this.groupBox8.Controls.Add(this.txtMD5Key);
            this.groupBox8.Location = new System.Drawing.Point(439, 177);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(400, 180);
            this.groupBox8.TabIndex = 24;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "设置MD5校验KEY(超级用户权限/普通用户具备写权限)";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.softdigest);
            this.groupBox10.Controls.Add(this.label21);
            this.groupBox10.Controls.Add(this.label20);
            this.groupBox10.Controls.Add(this.txtVerifyResult);
            this.groupBox10.Controls.Add(this.btnVerifyMd5HMAC);
            this.groupBox10.Controls.Add(this.label15);
            this.groupBox10.Controls.Add(this.txtVerifyRandom);
            this.groupBox10.Location = new System.Drawing.Point(6, 54);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(388, 106);
            this.groupBox10.TabIndex = 11;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "验证";
            // 
            // softdigest
            // 
            this.softdigest.Location = new System.Drawing.Point(56, 45);
            this.softdigest.Name = "softdigest";
            this.softdigest.Size = new System.Drawing.Size(194, 21);
            this.softdigest.TabIndex = 16;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(3, 51);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 12);
            this.label21.TabIndex = 15;
            this.label21.Text = "软件结果";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(1, 82);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 12);
            this.label20.TabIndex = 14;
            this.label20.Text = "硬件结果";
            // 
            // txtVerifyResult
            // 
            this.txtVerifyResult.Location = new System.Drawing.Point(56, 77);
            this.txtVerifyResult.Name = "txtVerifyResult";
            this.txtVerifyResult.Size = new System.Drawing.Size(194, 21);
            this.txtVerifyResult.TabIndex = 13;
            // 
            // btnVerifyMd5HMAC
            // 
            this.btnVerifyMd5HMAC.Location = new System.Drawing.Point(262, 31);
            this.btnVerifyMd5HMAC.Name = "btnVerifyMd5HMAC";
            this.btnVerifyMd5HMAC.Size = new System.Drawing.Size(113, 47);
            this.btnVerifyMd5HMAC.TabIndex = 12;
            this.btnVerifyMd5HMAC.Text = "硬件验证";
            this.btnVerifyMd5HMAC.UseVisualStyleBackColor = true;
            this.btnVerifyMd5HMAC.Click += new System.EventHandler(this.btnVerifyMd5HMAC_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(3, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 12);
            this.label15.TabIndex = 11;
            this.label15.Text = "随机数:";
            // 
            // txtVerifyRandom
            // 
            this.txtVerifyRandom.Location = new System.Drawing.Point(56, 18);
            this.txtVerifyRandom.Name = "txtVerifyRandom";
            this.txtVerifyRandom.Size = new System.Drawing.Size(194, 21);
            this.txtVerifyRandom.TabIndex = 0;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(3, 23);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 12);
            this.label13.TabIndex = 10;
            this.label13.Text = "标志位:";
            // 
            // txtKeyID
            // 
            this.txtKeyID.Location = new System.Drawing.Point(53, 20);
            this.txtKeyID.Name = "txtKeyID";
            this.txtKeyID.Size = new System.Drawing.Size(21, 21);
            this.txtKeyID.TabIndex = 9;
            this.txtKeyID.Text = "1";
            // 
            // btnSetMd5Key
            // 
            this.btnSetMd5Key.Location = new System.Drawing.Point(268, 18);
            this.btnSetMd5Key.Name = "btnSetMd5Key";
            this.btnSetMd5Key.Size = new System.Drawing.Size(113, 23);
            this.btnSetMd5Key.TabIndex = 8;
            this.btnSetMd5Key.Text = "写入KEY";
            this.btnSetMd5Key.UseVisualStyleBackColor = true;
            this.btnSetMd5Key.Click += new System.EventHandler(this.btnSetMd5Key_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(83, 23);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(29, 12);
            this.label11.TabIndex = 7;
            this.label11.Text = "KEY:";
            // 
            // txtMD5Key
            // 
            this.txtMD5Key.Location = new System.Drawing.Point(115, 20);
            this.txtMD5Key.Name = "txtMD5Key";
            this.txtMD5Key.Size = new System.Drawing.Size(135, 21);
            this.txtMD5Key.TabIndex = 6;
            this.txtMD5Key.Text = "1234567";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label18);
            this.groupBox9.Controls.Add(this.txtUserpinRetries);
            this.groupBox9.Controls.Add(this.label19);
            this.groupBox9.Controls.Add(this.label17);
            this.groupBox9.Controls.Add(this.txtSopinRetries);
            this.groupBox9.Controls.Add(this.label16);
            this.groupBox9.Controls.Add(this.btnSetup);
            this.groupBox9.Controls.Add(this.rdoWriteRead);
            this.groupBox9.Controls.Add(this.rdoReadOnly);
            this.groupBox9.Controls.Add(this.label14);
            this.groupBox9.Location = new System.Drawing.Point(439, 391);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(400, 160);
            this.groupBox9.TabIndex = 25;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "设备设置（超级用户权限）";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(221, 54);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(101, 12);
            this.label18.TabIndex = 18;
            this.label18.Text = "0 表示永远不被锁";
            // 
            // txtUserpinRetries
            // 
            this.txtUserpinRetries.Location = new System.Drawing.Point(188, 51);
            this.txtUserpinRetries.Name = "txtUserpinRetries";
            this.txtUserpinRetries.Size = new System.Drawing.Size(21, 21);
            this.txtUserpinRetries.TabIndex = 17;
            this.txtUserpinRetries.Text = "0";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 54);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(179, 12);
            this.label19.TabIndex = 16;
            this.label19.Text = "普通用户PIN的重试次数（0-15）";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(221, 26);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(101, 12);
            this.label17.TabIndex = 15;
            this.label17.Text = "0 表示永远不被锁";
            // 
            // txtSopinRetries
            // 
            this.txtSopinRetries.Location = new System.Drawing.Point(188, 23);
            this.txtSopinRetries.Name = "txtSopinRetries";
            this.txtSopinRetries.Size = new System.Drawing.Size(21, 21);
            this.txtSopinRetries.TabIndex = 14;
            this.txtSopinRetries.Text = "0";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 26);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(179, 12);
            this.label16.TabIndex = 13;
            this.label16.Text = "超级用户PIN的重试次数（0-15）";
            // 
            // btnSetup
            // 
            this.btnSetup.Location = new System.Drawing.Point(22, 112);
            this.btnSetup.Name = "btnSetup";
            this.btnSetup.Size = new System.Drawing.Size(359, 38);
            this.btnSetup.TabIndex = 12;
            this.btnSetup.Text = "设 置";
            this.btnSetup.UseVisualStyleBackColor = true;
            this.btnSetup.Click += new System.EventHandler(this.btnSetup_Click);
            // 
            // rdoWriteRead
            // 
            this.rdoWriteRead.AutoSize = true;
            this.rdoWriteRead.Checked = true;
            this.rdoWriteRead.Location = new System.Drawing.Point(145, 81);
            this.rdoWriteRead.Name = "rdoWriteRead";
            this.rdoWriteRead.Size = new System.Drawing.Size(59, 16);
            this.rdoWriteRead.TabIndex = 11;
            this.rdoWriteRead.TabStop = true;
            this.rdoWriteRead.Text = "可读写";
            this.rdoWriteRead.UseVisualStyleBackColor = true;
            // 
            // rdoReadOnly
            // 
            this.rdoReadOnly.AutoSize = true;
            this.rdoReadOnly.Location = new System.Drawing.Point(210, 81);
            this.rdoReadOnly.Name = "rdoReadOnly";
            this.rdoReadOnly.Size = new System.Drawing.Size(47, 16);
            this.rdoReadOnly.TabIndex = 10;
            this.rdoReadOnly.Text = "只读";
            this.rdoReadOnly.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(20, 83);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(107, 12);
            this.label14.TabIndex = 9;
            this.label14.Text = "普通用户读写标志:";
            // 
            // btnLED
            // 
            this.btnLED.Location = new System.Drawing.Point(18, 557);
            this.btnLED.Name = "btnLED";
            this.btnLED.Size = new System.Drawing.Size(370, 23);
            this.btnLED.TabIndex = 26;
            this.btnLED.Tag = "on";
            this.btnLED.Text = "打开/关闭LED灯";
            this.btnLED.UseVisualStyleBackColor = true;
            this.btnLED.Click += new System.EventHandler(this.btnLED_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.lab_write_read);
            this.groupBox11.Controls.Add(this.btn_clear);
            this.groupBox11.Controls.Add(this.btn_read);
            this.groupBox11.Controls.Add(this.label23);
            this.groupBox11.Controls.Add(this.label22);
            this.groupBox11.Controls.Add(this.txt_read);
            this.groupBox11.Controls.Add(this.txt_write);
            this.groupBox11.Controls.Add(this.btn_write);
            this.groupBox11.Location = new System.Drawing.Point(18, 377);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(394, 160);
            this.groupBox11.TabIndex = 28;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "写入存储区";
            // 
            // lab_write_read
            // 
            this.lab_write_read.AutoSize = true;
            this.lab_write_read.Location = new System.Drawing.Point(91, 14);
            this.lab_write_read.Name = "lab_write_read";
            this.lab_write_read.Size = new System.Drawing.Size(89, 12);
            this.lab_write_read.TabIndex = 8;
            this.lab_write_read.Text = "lab_write_read";
            // 
            // btn_clear
            // 
            this.btn_clear.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_clear.Location = new System.Drawing.Point(115, 107);
            this.btn_clear.Name = "btn_clear";
            this.btn_clear.Size = new System.Drawing.Size(116, 33);
            this.btn_clear.TabIndex = 6;
            this.btn_clear.Text = "3--重置 存储区";
            this.btn_clear.UseVisualStyleBackColor = true;
            this.btn_clear.Click += new System.EventHandler(this.btn_clear_Click);
            // 
            // btn_read
            // 
            this.btn_read.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_read.Location = new System.Drawing.Point(267, 66);
            this.btn_read.Name = "btn_read";
            this.btn_read.Size = new System.Drawing.Size(108, 29);
            this.btn_read.TabIndex = 5;
            this.btn_read.Text = "2--确定【读】";
            this.btn_read.UseVisualStyleBackColor = true;
            this.btn_read.Click += new System.EventHandler(this.btn_read_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label23.Location = new System.Drawing.Point(7, 77);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(17, 12);
            this.label23.TabIndex = 4;
            this.label23.Text = "读";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label22.Location = new System.Drawing.Point(3, 32);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(17, 12);
            this.label22.TabIndex = 3;
            this.label22.Text = "写";
            // 
            // txt_read
            // 
            this.txt_read.Location = new System.Drawing.Point(50, 68);
            this.txt_read.Name = "txt_read";
            this.txt_read.Size = new System.Drawing.Size(194, 21);
            this.txt_read.TabIndex = 2;
            this.txt_read.Text = "读取成功后，赋值到这个文本框";
            // 
            // txt_write
            // 
            this.txt_write.Location = new System.Drawing.Point(50, 29);
            this.txt_write.Name = "txt_write";
            this.txt_write.Size = new System.Drawing.Size(194, 21);
            this.txt_write.TabIndex = 1;
            // 
            // btn_write
            // 
            this.btn_write.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.btn_write.Location = new System.Drawing.Point(267, 23);
            this.btn_write.Name = "btn_write";
            this.btn_write.Size = new System.Drawing.Size(108, 30);
            this.btn_write.TabIndex = 0;
            this.btn_write.Text = "1--确定【写】";
            this.btn_write.UseVisualStyleBackColor = true;
            this.btn_write.Click += new System.EventHandler(this.btn_write_Click);
            // 
            // frmET99API
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(851, 607);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.btnLED);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmET99API";
            this.Text = "ET99加密锁初始化工具";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnFind;
        private System.Windows.Forms.TextBox txtOldPid;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSeed;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNewPID;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnGenPID;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPin;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rdoSoPin;
        private System.Windows.Forms.RadioButton rdoUserPin;
        private System.Windows.Forms.Button btnVerify;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnModifyUserPin;
        private System.Windows.Forms.TextBox txtOldUserPin;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtNewUserPin;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSN;
        private System.Windows.Forms.Button btnGetSN;
        private System.Windows.Forms.Button btnResetStatus;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Button btnGenSoPin;
        private System.Windows.Forms.TextBox txtNewSoPin;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtGenSoPinSeed;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Button btnResetUserPin;
        private System.Windows.Forms.TextBox txtSoPin;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btnSetMd5Key;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtMD5Key;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtKeyID;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button btnSetup;
        private System.Windows.Forms.RadioButton rdoWriteRead;
        private System.Windows.Forms.RadioButton rdoReadOnly;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtSopinRetries;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtUserpinRetries;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnLED;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtVerifyRandom;
        private System.Windows.Forms.Button btnVerifyMd5HMAC;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtVerifyResult;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Button btn_write;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txt_read;
        private System.Windows.Forms.TextBox txt_write;
        private System.Windows.Forms.Button btn_read;
        private System.Windows.Forms.Button btn_clear;
        private System.Windows.Forms.Label lab_write_read;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox softdigest;
    }
}