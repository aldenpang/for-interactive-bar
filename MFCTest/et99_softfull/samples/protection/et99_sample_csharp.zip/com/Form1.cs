using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Runtime.InteropServices;
using ET99_MODLib;
using ET99_FULLLib;

namespace ET99Test
{
	/// <summary>
	/// Form1 ��ժҪ˵����
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button OpenToken;
		private System.Windows.Forms.Button WriteData;
		private System.Windows.Forms.Button ReadData;
		private System.Windows.Forms.Button CloseToken;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox PidEdit;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox UserPinEdit;
		
		private ET99_MODLib.ET99MOD ET99=new ET99MODClass();
        //private ET99_FULLLib.ET99Full et99full=new ET99FullClass();
        
        private Button SetMD5Key;
        private Button ET99cal;
        private Button softcal;
        private TextBox kettext;
        private TextBox randomtext;
        private Label label3;
        private Label label4;
		/// <summary>
		/// ����������������
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Windows ���������֧���������
			//
			InitializeComponent();

			//
			// TODO: �� InitializeComponent ���ú������κι��캯������
			//
		}

		/// <summary>
		/// ������������ʹ�õ���Դ��
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows ������������ɵĴ���
		/// <summary>
		/// �����֧������ķ��� - ��Ҫʹ�ô���༭���޸�
		/// �˷��������ݡ�
		/// </summary>
		private void InitializeComponent()
		{
            this.OpenToken = new System.Windows.Forms.Button();
            this.WriteData = new System.Windows.Forms.Button();
            this.ReadData = new System.Windows.Forms.Button();
            this.CloseToken = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.PidEdit = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.UserPinEdit = new System.Windows.Forms.TextBox();
            this.SetMD5Key = new System.Windows.Forms.Button();
            this.ET99cal = new System.Windows.Forms.Button();
            this.softcal = new System.Windows.Forms.Button();
            this.kettext = new System.Windows.Forms.TextBox();
            this.randomtext = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // OpenToken
            // 
            this.OpenToken.Enabled = false;
            this.OpenToken.Location = new System.Drawing.Point(24, 112);
            this.OpenToken.Name = "OpenToken";
            this.OpenToken.Size = new System.Drawing.Size(75, 23);
            this.OpenToken.TabIndex = 0;
            this.OpenToken.Text = "OpenToken";
            this.OpenToken.Click += new System.EventHandler(this.OpenToken_Click);
            // 
            // WriteData
            // 
            this.WriteData.Location = new System.Drawing.Point(136, 112);
            this.WriteData.Name = "WriteData";
            this.WriteData.Size = new System.Drawing.Size(75, 23);
            this.WriteData.TabIndex = 1;
            this.WriteData.Text = "Write";
            this.WriteData.Click += new System.EventHandler(this.WriteData_Click);
            // 
            // ReadData
            // 
            this.ReadData.Location = new System.Drawing.Point(256, 112);
            this.ReadData.Name = "ReadData";
            this.ReadData.Size = new System.Drawing.Size(75, 23);
            this.ReadData.TabIndex = 2;
            this.ReadData.Text = "Read";
            this.ReadData.Click += new System.EventHandler(this.ReadData_Click);
            // 
            // CloseToken
            // 
            this.CloseToken.Location = new System.Drawing.Point(368, 112);
            this.CloseToken.Name = "CloseToken";
            this.CloseToken.Size = new System.Drawing.Size(75, 23);
            this.CloseToken.TabIndex = 3;
            this.CloseToken.Text = "CloseToken";
            this.CloseToken.Click += new System.EventHandler(this.CloseToken_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(48, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 4;
            this.label1.Text = "TokenPid:";
            // 
            // PidEdit
            // 
            this.PidEdit.Location = new System.Drawing.Point(120, 16);
            this.PidEdit.Name = "PidEdit";
            this.PidEdit.Size = new System.Drawing.Size(176, 21);
            this.PidEdit.TabIndex = 5;
            this.PidEdit.TextChanged += new System.EventHandler(this.PidEdit_TextChanged);
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(40, 64);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "User Pin:";
            // 
            // UserPinEdit
            // 
            this.UserPinEdit.Location = new System.Drawing.Point(120, 64);
            this.UserPinEdit.Name = "UserPinEdit";
            this.UserPinEdit.PasswordChar = '*';
            this.UserPinEdit.Size = new System.Drawing.Size(176, 21);
            this.UserPinEdit.TabIndex = 7;
            this.UserPinEdit.TextChanged += new System.EventHandler(this.UserPinEdit_TextChanged);
            // 
            // SetMD5Key
            // 
            this.SetMD5Key.Location = new System.Drawing.Point(136, 153);
            this.SetMD5Key.Name = "SetMD5Key";
            this.SetMD5Key.Size = new System.Drawing.Size(75, 23);
            this.SetMD5Key.TabIndex = 8;
            this.SetMD5Key.Text = "SetMD5Key";
            this.SetMD5Key.UseVisualStyleBackColor = true;
            this.SetMD5Key.Click += new System.EventHandler(this.button1_Click);
            // 
            // ET99cal
            // 
            this.ET99cal.Location = new System.Drawing.Point(256, 153);
            this.ET99cal.Name = "ET99cal";
            this.ET99cal.Size = new System.Drawing.Size(75, 22);
            this.ET99cal.TabIndex = 9;
            this.ET99cal.Text = "Ӳ������";
            this.ET99cal.UseVisualStyleBackColor = true;
            this.ET99cal.Click += new System.EventHandler(this.button2_Click);
            // 
            // softcal
            // 
            this.softcal.Location = new System.Drawing.Point(370, 154);
            this.softcal.Name = "softcal";
            this.softcal.Size = new System.Drawing.Size(72, 21);
            this.softcal.TabIndex = 10;
            this.softcal.Text = "��������";
            this.softcal.UseVisualStyleBackColor = true;
            this.softcal.Click += new System.EventHandler(this.button3_Click);
            // 
            // kettext
            // 
            this.kettext.Location = new System.Drawing.Point(383, 16);
            this.kettext.Name = "kettext";
            this.kettext.Size = new System.Drawing.Size(112, 21);
            this.kettext.TabIndex = 11;
            // 
            // randomtext
            // 
            this.randomtext.Location = new System.Drawing.Point(384, 61);
            this.randomtext.Name = "randomtext";
            this.randomtext.Size = new System.Drawing.Size(110, 21);
            this.randomtext.TabIndex = 12;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(315, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 13;
            this.label3.Text = "MD5��Կ";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(315, 68);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 14;
            this.label4.Text = "�����";
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
            this.ClientSize = new System.Drawing.Size(578, 201);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.randomtext);
            this.Controls.Add(this.kettext);
            this.Controls.Add(this.softcal);
            this.Controls.Add(this.ET99cal);
            this.Controls.Add(this.SetMD5Key);
            this.Controls.Add(this.UserPinEdit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PidEdit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.CloseToken);
            this.Controls.Add(this.ReadData);
            this.Controls.Add(this.WriteData);
            this.Controls.Add(this.OpenToken);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// Ӧ�ó��������ڵ㡣
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}
		private void testfun1(out int a)
		{
			a=10;
		}
		private void testfun2(ref byte b)
		{
		}
		private void testfun3(ref byte b,out int a)
		{
			b=b;
			a=10;
		}

        public string byteTostring(byte[] byTemp, int len)
        {
            string strtemp = "";
            for (int j = 0; j < len; j++)
            {
                if (byTemp[j] == 0)
                {
                    break;
                }
                strtemp += string.Format("{0}", (char)byTemp[j]);
            }
            return strtemp;
        }
		
		private void OpenToken_Click(object sender, System.EventArgs e)
		{
			try
			{
				byte[] pid = new byte[8];
				char[] chpid = new char[8];
				byte[] pin = new byte[16];
				char[] chpin = new char[16];
				int TokenCount=0;

				//data type convert
				PidEdit.Text.CopyTo(0,chpid,0,8);
				UserPinEdit.Text.CopyTo(0,chpin,0,16);
				for(int i=0;i<8;i++)
				{
					pid[i]=(byte)chpid[i];
				}
				for(int j=0;j<16;j++)
				{
					pin[j]=(byte)chpin[j];
				}

				//find ET99
				//			testfun1(out TokenCount);
				//			testfun2(ref pid[0]);
				//			testfun3(ref pid[0],out TokenCount);
				ET99.FindToken(ref pid[0],out TokenCount);

				if(0==TokenCount)
				{
					MessageBox.Show("Not found any ET99!");
					return;
				}

				//open the first ET99
				ET99.OpenToken(ref pid[0],1);

				//verify user pin
				ET99.VerifyPIN(0,ref pin[0]);

				MessageBox.Show("Open ET99 success!");
				OpenToken.Enabled = false;
				WriteData.Enabled = true;
				ReadData.Enabled = true;
				CloseToken.Enabled = true;
                SetMD5Key.Enabled = true;
                ET99cal.Enabled = true;
                softcal.Enabled = true;
				PidEdit.Text="";
				UserPinEdit.Text="";

			}
			catch(COMException exc)
			{
				MessageBox.Show(String.Format("error code {0}",(exc.ErrorCode &0xff)) );

				MessageBox.Show("open Token fail!");
			}
		}

		private void WriteData_Click(object sender, System.EventArgs e)
		{
			try
			{
				byte[] buffer = new byte[8];
                
                byte[] bytArr;
                string strwrite = "ET99ET99";

                bytArr = System.Text.Encoding.ASCII.GetBytes(strwrite.ToCharArray());
                System.Buffer.BlockCopy(bytArr, 0, buffer, 0, 8);


				ET99.Write(0,8,ref buffer[0]);
				MessageBox.Show("Write ET99 success!");
			}
			catch(COMException exc)
			{
				MessageBox.Show(String.Format("error code {0}",(exc.ErrorCode &0xff)) );
				MessageBox.Show("Write ET99 fail!");
			}
		}

		private void ReadData_Click(object sender, System.EventArgs e)
		{
			try
			{
                byte[] buffer = new byte[8];
                string strtemp;

                ET99.Read(0,8,out buffer[0]);

                strtemp = byteTostring(buffer, 8);

                MessageBox.Show("Read ET99 success!" + strtemp);
			}
			catch(COMException exc)
			{
				MessageBox.Show(String.Format("error code {0}",(exc.ErrorCode &0xff)) );
				MessageBox.Show("Read ET99 fail!");
			}

		}

		private void CloseToken_Click(object sender, System.EventArgs e)
		{
			ET99.CloseToken();
			OpenToken.Enabled = true;
			WriteData.Enabled = false;
			ReadData.Enabled = false;
			CloseToken.Enabled = false;
            SetMD5Key.Enabled = false;
            ET99cal.Enabled = false;
            softcal.Enabled = false;
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			OpenToken.Enabled = true;
			WriteData.Enabled = false;
			ReadData.Enabled = false;
			CloseToken.Enabled = false;
            SetMD5Key.Enabled = false;
            ET99cal.Enabled = false;
            softcal.Enabled = false;
		}

		private void PidEdit_TextChanged(object sender, System.EventArgs e)
		{
            if((PidEdit.Text.Length!=8)||(UserPinEdit.Text.Length!=16))
				OpenToken.Enabled = false;
			else
				OpenToken.Enabled = true;		
		}

		private void UserPinEdit_TextChanged(object sender, System.EventArgs e)
		{
			if((PidEdit.Text.Length!=8)||(UserPinEdit.Text.Length!=16))
				OpenToken.Enabled = false;
			else
				OpenToken.Enabled = true;	
		}

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                //������û�����Կ�������Կ�Ǵ洢�����ݿ��У��������������
                byte[] bytekey;
                //string strkey = "123456";
                string strkey = kettext.Text;

                //��������û�����Կ���д�����������123456���������Ϊ������32�ֽ�MD5��Կ
                //�洢��ET99�У������Կ������Ӳ�������
                byte[] md5keybuffer = new byte[32];

                
                //��������ڲ�����Կʱû����
                byte[] randombuffer  = new byte[51];
                //��������������Ҳû����
                byte[] digest = new byte[16];

                bytekey = System.Text.Encoding.ASCII.GetBytes(strkey.ToCharArray());

                //����123456����Ϊ32�ֽڵ�MD5��Կ
                ET99.Soft_MD5HMAC(ref randombuffer[0], 51, 
                    ref bytekey[0], strkey.Length, 
                    out md5keybuffer[0], out digest[0]);

                //��32�ֽڵ�MD5��Կ�洢��ET99�У���Կ��Ϊ1
                ET99.SetKey(1, ref md5keybuffer[0]);

                MessageBox.Show("Set MD5KEY success!");
            }
            catch (COMException exc)
            {
                MessageBox.Show(String.Format("error code {0}", (exc.ErrorCode & 0xff)));
                MessageBox.Show("Read ET99 fail!");
            }


        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                //�����������Ӳ������
                //string strrandom = "88889999";
                string strrandom = randomtext.Text;
                byte[] byterandom;

               //Ӳ��������
                byte[] et99digest = new byte[16];

               string strtemp = "";
               
                byterandom = System.Text.Encoding.ASCII.GetBytes(strrandom.ToCharArray());

                //ʹ��MD5��Կ��Ϊ1����Կ���㣬
                ET99.MD5HMAC(1, strrandom.Length, ref byterandom[0], out et99digest[0]);

                for (int i = 0; i < 16; ++i)
                {
                    strtemp += string.Format("{0:X2}", et99digest[i]);
                    
                }



                MessageBox.Show(strtemp);
            }
            catch (COMException exc)
            {
                MessageBox.Show(String.Format("error code {0}", (exc.ErrorCode & 0xff)));
                MessageBox.Show("Read ET99 fail!");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                //��������ڲ�����Կʱû����
                //string strrandom = "88889999";
                string strrandom = randomtext.Text;
                byte[] byterandom;

                //��������Կ�������ݿ���
                byte[] bytekey;
                //string strkey = "123456";
                string strkey = kettext.Text;

                //����������
                byte[] softdigest = new byte[16];

                //�����MD5��Կ��������û����
                byte[] md5keybuffer = new byte[32];

                string strtemp = "";

                
                byterandom = System.Text.Encoding.ASCII.GetBytes(strrandom.ToCharArray());
                bytekey = System.Text.Encoding.ASCII.GetBytes(strkey.ToCharArray());


                ET99.Soft_MD5HMAC(ref byterandom[0], strrandom.Length,
                    ref bytekey[0], strkey.Length,
                    out md5keybuffer[0], out softdigest[0]);

                for (int i = 0; i < 16; ++i)
                {
                    strtemp += string.Format("{0:X2}", softdigest[i]);

                }



                MessageBox.Show(strtemp);
            }
            catch (COMException exc)
            {
                MessageBox.Show(String.Format("error code {0}", (exc.ErrorCode & 0xff)));
                MessageBox.Show("Read ET99 fail!");
            }

        }

	}
}
