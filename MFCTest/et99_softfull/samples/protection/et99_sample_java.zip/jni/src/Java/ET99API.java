package ET99jni;


public class ET99API
{

    public ET99API()
    {
        bInit = 0;
        LoadLibrary();
    }

    public void finalize()
    {
        if(bInit == 1)
        {
            bInit = 0;
            FreeLibrary();
        }
    }

    public void Thrown1(int i, String s)
    {
        throw new RTException(i, s);
    }

    public void Thrown2(int i)
    {
        throw new RTException(i);
    }

    private native void LoadLibrary();

    private native void FreeLibrary();
    
    public native void FindToken(byte abyte[], int ai[]);

    public native void OpenToken(byte abyte[], int j);

    public native void CloseToken();

    public native void Read(int i, int j, byte abyte0[]);

    public native void Write(int i, int j, byte abyte0[]);

    public native void GenRandom(byte abyte0[]);

    public native void MD5HMAC(int i, byte abyte0[], int k, byte abyte1[]);

    public native void Verify(int i, byte abyte0[]);

    public native void ChangeUserPIN(byte abyte0[], byte abyte1[]);

    public native void ResetSecurityState();

    public native void SoftMD5HMAC(byte abyte0[], int i, byte abyte1[], int j, byte abyte2[], byte abyte3[]);
    
    public native void GenPid(byte abyte0[], int i, byte abyte1[]);
    
    public native void GenSoPIN(byte abyte0[], int i, byte abyte1[]);
    
    public native void ResetPIN(byte abyte[]);
    
    public native void SetKey(int i, byte abyte[]);
    
    public native void GetPid(int aint[]);
    
    public native void GetSN(byte abyte[]);
    
    public native void SetupToken(int i, int j, int k, int m);
    
    public native void TurnOnLED();
    
    public native void TurnOffLED();

    private int hCtx;
    private int bInit;

    static 
    {
        System.loadLibrary("JET99ai20");
    }
}
