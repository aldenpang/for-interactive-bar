package ET99jni;

public class CET99
    implements IET99
{

    public CET99()
    {
        ET99 = new ET99API();
    }
    
    public void FindToken(byte abyte0[], int j[])
    {
        ET99.FindToken(abyte0, j);
    }

    public void OpenToken(byte abyte0[], int j)
    {
        ET99.OpenToken(abyte0, j);
    }

    public void CloseToken()
    {
        ET99.CloseToken();
    }

    public void Read(int i, int j, byte abyte0[])
    {
        ET99.Read(i, j, abyte0);
    }

    public void Write(int i, int j, byte abyte0[])
    {
        ET99.Write(i, j, abyte0);
    }

    public void GenRandom(byte abyte0[])
    {
        ET99.GenRandom(abyte0);
    }

    public void MD5HMAC(int i, byte abyte0[], int k, byte abyte1[])
    {
        ET99.MD5HMAC(i, abyte0, k, abyte1);
    }

    public void Verify(int i, byte abyte0[])
    {
        ET99.Verify(i, abyte0);
    }

    public void ChangeUserPIN(byte abyte0[], byte abyte1[])
    {
        ET99.ChangeUserPIN(abyte0, abyte1);
    }

    public void ResetSecurityState()
    {
        ET99.ResetSecurityState();
    }
    
    public void SoftMD5HMAC(byte abyte0[], int i, byte abyte1[], int j, byte abyte2[], byte abyte3[])
    {
    	ET99.SoftMD5HMAC(abyte0, i, abyte1, j, abyte2, abyte3);
    }
    
    public void GenPid(byte abyte0[], int i, byte abyte1[])
    {
    	ET99.GenPid(abyte0, i, abyte1);
    }
    
    public void GenSoPIN(byte abyte0[], int i, byte abyte1[])
    {
    	ET99.GenSoPIN(abyte0, i, abyte1);
    }
    
    public void ResetPIN(byte abyte[])
    {
    	ET99.ResetPIN(abyte);
    }
    
    public void SetKey(int i, byte abyte[])
    {
    	ET99.SetKey(i, abyte);
    }
     
    public void GetSN(byte abyte[])
    {
    	ET99.GetSN(abyte);
    }
    
    public void SetupToken(int i, int j, int k, int m)
    {
    	ET99.SetupToken(i, j, k, m);
    }
    
    public void TurnOnLED()
    {
    	ET99.TurnOnLED();
    }
    
    public void TurnOffLED()
    {
    	ET99.TurnOffLED();
    }

    private ET99API ET99;
}
