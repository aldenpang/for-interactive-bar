package ET99jni;


public interface IET99
{
	public abstract void FindToken(byte pid[]/*[in]*/, int tokenCount[]/*out*/);

    public abstract void OpenToken(byte pid[]/*[in]*/, int index/*[in]*/);

    public abstract void CloseToken();

    public abstract void Read(int offset/*[in]*/,int Len/*[in]*/,byte pBuffer[]/*[out]*/);

    public abstract void Write(int offset/*[in]*/,int Len/*[in]*/,byte pBuffer[]/*[in]*/);

    public abstract void GenRandom(byte pBuffer[]/*[out]*/);

    public abstract void MD5HMAC(int KeyId/*[in]*/,byte pText[]/*[in]*/,int lTextLen/*[in]*/,byte pDigest[]/*[out]*/);

    public abstract void Verify(int lFlags/*[in]*/,byte pData[]/*[in]*/);

    public abstract void ChangeUserPIN(byte pOldCode[]/*[in]*/,byte pNewCode[]/*[in]*/);

    public abstract void ResetSecurityState();

    public abstract void SoftMD5HMAC(byte pText[]/*[in]*/, int lTextLen/*[in]*/, byte AuthKey[]/*[in]*/, int lAuthKeyLen/*[in]*/, byte TokenKey[]/*[out]*/, byte pDigest[]/*[out]*/);
    
    public abstract void GenPid(byte pSeed[]/*[in]*/, int lSeedLen/*[in]*/, byte pid[]/*[out]*/);
    
    public abstract void GenSoPIN(byte pSeed[]/*[in]*/, int lSeedLen/*[in]*/, byte pSoPin[]/*[out]*/);
     
    public abstract void ResetPIN(byte pSoPin[]/*[in]*/);
    
    public abstract void SetKey(int keyId/*[in]*/, byte pKey[]/*[in]*/);
        
    public abstract void GetSN(byte pSN[]/*[out]*/);
    
    public abstract void SetupToken(int soPinRetry/*[in]*/, int userPinRetry/*[in]*/, int readOnly/*[in]*/, int Reserved/*[in]*/);
    
    public abstract void TurnOnLED();
    
    public abstract void TurnOffLED();
}
