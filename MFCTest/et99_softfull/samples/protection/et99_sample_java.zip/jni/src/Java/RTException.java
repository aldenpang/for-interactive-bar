package ET99jni;


public class RTException extends RuntimeException
{

    public RTException()
    {
        retval = 0;
    }

    public RTException(int i)
    {
        retval = i;
    }

    public RTException(int i, String s)
    {
        super(s);
        retval = i;
    }

    public RTException(String s)
    {
        super(s);
        retval = 0;
    }

    public int HResult()
    {
        if(retval == 0)
        {
            int i = getMessage().lastIndexOf("0x");
            if(i != -1)
            {
                String s = getMessage().substring(i + 6);
                retval = Integer.parseInt(s, 16);
            }
        }
        return retval;
    }

    private int retval;
}
