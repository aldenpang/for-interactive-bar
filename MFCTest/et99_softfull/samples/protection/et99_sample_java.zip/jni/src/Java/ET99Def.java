package ET99jni;


public class ET99Def
{

    public ET99Def()
    {
    }

    public static final int ET_SUCCESS = 0;
    public static final int ET_ACCESS_DENY = 1;
    public static final int ET_COMMUNICATIONS_ERROR = 2;
    public static final int ET_INVALID_PARAMETER = 3;
    public static final int ET_NOT_SET_PID = 4;
    public static final int ET_NOTFOUND_DEVICE = 5;
    public static final int ET_HEAD_ERROR = 6;
    public static final int ET_UNKNOWN = 7;
    public static final int ET_VERIFY_USERPIN = 0;
    public static final int ET_VERIFY_SOPIN = 1;
    public static final int ET_USER_WRITE_READ = 0;
    public static final int ET_USER_READ_ONLY = 1;
    public static final int ET_LED_ON = 0;
    public static final int ET_LED_OFF = 1;
}
