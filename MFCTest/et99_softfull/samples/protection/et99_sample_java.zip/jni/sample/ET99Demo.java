import ET99jni.*;
import java.lang.*;
import java.io.*;

public class ET99Demo
{
	// This routine converts bytes into hexadecimal representation
    public static char Hex(int bin) 
    {
        char retval;
        
        if (bin >= 0 && bin <= 9)
            retval = (char)('0' + bin);
        else if (bin >= 10 && bin <= 15)
            retval = (char)('A' + bin - 10);
        else
            retval = '0';
        return retval;
    }
    public static int B2Int(byte [] bina) 
    {
        int retval = 0;
        int t1 = 0;
        
        t1 = bina[3];
        retval = t1 & 0xFF;
        t1 = bina[2] & 0xFF;
        retval = retval * 0x100 + t1;
        t1 = bina[1] & 0xFF;
        retval = retval * 0x100 + t1;
        t1 = bina[0] & 0xFF;
        retval = retval * 0x100 + t1;
        return retval;
    }
    public static void TSleep()
    {
    	try
    	{
    		Thread.sleep(1000);
    	}
    	catch(InterruptedException e)
    	{
			System.err.println("Trouble with the lamp flash.");
		}
    }
	public static void main(String[] args)
	{
		IET99 ET99 = new CET99();
		ET99Def flag = new ET99Def();
		byte[] tText = new byte[64];
		String chPid = "";
		String chPin = "";
		String chSoPin = "";
		String Seed = "1234567890";
		boolean DigestFlag = true;
		
		byte[] TokenKey = new byte[32];
		byte[] TokenDigest = new byte[16];
		byte[] SoftDigest = new byte[16];
		byte[] bSeed = new byte[10];
		byte[] ran = new byte[16];
		byte[] SN = new byte[8];
		int[] tokenCount = new int[1];
		byte[] pid = new byte[8];
		byte[] userPin = new byte[16];
		byte[] soPin = new byte[16];
		char[] charPid = new char[8];
		char[] charPin = new char[16];
		char[] charSoPin = new char[16];
		char[] newPid = new char[8];
		char[] newSoPin = new char[16];
		
		for(int j=0;j<10;j++)
		{
			bSeed[j] = (byte)Seed.charAt(j);
		}
		
		BufferedReader lineOfText = new BufferedReader(new InputStreamReader(System.in));
		try
		{
			System.out.println("Please input PID of the first ET99 (8 char) : ");
			chPid = lineOfText.readLine();
			for(int i=0;i<8;i++)
			{
				charPid[i] = chPid.charAt(i);
				pid[i] = (byte)charPid[i];
			}
			System.out.println("Please input User PIN of the first ET99 (16 char) : ");
			chPin = lineOfText.readLine();
			for(int j=0;j<16;j++)
			{
				charPin[j] = chPin.charAt(j);
				userPin[j] = (byte)charPin[j];
			}
			System.out.println("Please input SO PIN of the first ET99 (16 char) : ");
			chSoPin = lineOfText.readLine();
			for(int j=0;j<16;j++)
			{
				charSoPin[j] = chSoPin.charAt(j);
				soPin[j] = (byte)charSoPin[j];
			}
		}
		catch (IOException e)
		{
			System.err.println("Trouble with the input pid.");
		}
		
		try
		{
			System.out.println("Try to Find ET99...");
			ET99.FindToken(pid,tokenCount);
			if (tokenCount[0]!=0)
				System.out.println("Find ET99!");
			System.out.println("Try to open a token...");
			ET99.OpenToken(pid,1);
			System.out.println("Open a ET99 success!");
			System.out.println("Verify user pin...");
			ET99.Verify(0,userPin);
			System.out.println("Verify user pin success!");    
			System.out.println("Write ET99...");         
            ET99.Write(0, 16, userPin);
            System.out.println("Write succeed!" );
            System.out.println("Read ET99...");     
            ET99.Read(0, 16, tText);
			System.out.println("Read succeed! ");
			System.out.println("Get random...");            
            ET99.GenRandom(ran);
            System.out.println("Get random success!");
            System.out.println("Get SN...");            
            ET99.GetSN(SN);
            System.out.println("Get SN success!");
            System.out.println("SoftMD5HMAC generate token key...");
            ET99.SoftMD5HMAC(bSeed,10,bSeed,10,TokenKey,SoftDigest);
            System.out.println("SoftMD5HMAC generate token key success!");
            System.out.println("Set Token Key...");
            ET99.SetKey(1,TokenKey);
            System.out.println("Set Token Key success!");
            System.out.println("SoftMD5HMAC generate soft digest...");
            ET99.SoftMD5HMAC(bSeed,10,bSeed,10,TokenKey,SoftDigest);
            System.out.println("SoftMD5HMAC generate soft digest success!");
            System.out.println("MD5HMAC generate Token digest...");
            ET99.MD5HMAC(1,bSeed,10,TokenDigest);
            System.out.println("MD5HMAC generate Token digest success!");
            System.out.println("Compare Soft digest and Token digest...");
            for(int k=0;k<16;k++)
            {
            	if(TokenDigest[k]!=SoftDigest[k])
            	{
            		DigestFlag = false;
            		System.out.println("Compare Digest fail!");
            		break;
            	}
            }
            if(DigestFlag==true)
            	System.out.println("Compare Digest success!");
            System.out.println("Change User Pin...");
            ET99.ChangeUserPIN(userPin,userPin);
            System.out.println("Change User Pin success!");
            System.out.println("The lamp is flashing...");
            for(int j=0;j<5;j++)
            {
            	ET99.TurnOffLED();
            	TSleep();
            	ET99.TurnOnLED();
            	TSleep();       	
            }	
            System.out.println("The lamp is flashing finish.");
            System.out.println("Verify So pin...");
			ET99.Verify(1,soPin);
			System.out.println("Verify So pin success!");  
			System.out.println("SetupToken...");
			ET99.SetupToken(0,3,0,0);
			System.out.println("SetupToken success!");  
			//�����������ע�͵ĺ��������ס������PID��SoPIN
					//System.out.println("GenPid...");
					//ET99.GenPid(bSeed,10,pid);
					//System.out.println("GenPid success!");  
					//System.out.println("Gen So PIN ...");
					//ET99.GenSoPIN(bSeed,10,soPin);
					//System.out.println("Gen So PIN success!");
			System.out.println("ReSetPin ...");
			ET99.ResetPIN(soPin);
			System.out.println("ResetPin success!");
			System.out.println("Token user pin is FFFFFFFFFFFFFFFF");
            System.out.println("ResetSecurityState...");            
            ET99.ResetSecurityState();
            System.out.println("ResetSecurityState success!");
						
			System.out.println("Close the opened token...");
			ET99.CloseToken();
			System.out.println("Close the opened token success!");
		}
		catch(RTException e)
		{
			System.out.println(e.HResult()+":"+e.getMessage());
			ET99.CloseToken();
		}
	}
}
