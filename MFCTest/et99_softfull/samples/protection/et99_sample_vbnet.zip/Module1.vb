Option Strict Off
Option Explicit On
Module Module1
	'UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
	Declare Function et_FindToken Lib "FT_ET99_API.dll" (ByVal et99pid As String, ByRef et99count As Short) As Integer
	
	'UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
    Declare Function et_OpenToken Lib "FT_ET99_API.dll" (ByRef et99handle As Integer, ByVal et99pid As String, ByVal et99index As Short) As Integer
	
	Declare Function et_CloseToken Lib "FT_ET99_API.dll" (ByVal et99handle As Integer) As Integer
	
	Declare Function et_Write Lib "FT_ET99_API.dll" (ByVal et99handle As Integer, ByVal et99offset As Short, ByVal et99len As Short, ByRef et99write As Byte) As Integer
	
	Declare Function et_Read Lib "FT_ET99_API.dll" (ByVal et99handle As Integer, ByVal et99offset As Short, ByVal et99len As Short, ByRef et99read As Byte) As Integer
	
	'UPGRADE_ISSUE: Declaring a parameter 'As Any' is not supported. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="FAE78A8D-8978-4FD4-8208-5B7324A8F795"'
    Declare Function et_Verify Lib "FT_ET99_API.dll" (ByVal et99handle As Integer, ByVal et99flag As Short, ByVal et99pin As String) As Integer
	
	Declare Function et_GetSN Lib "FT_ET99_API.dll" (ByVal et99handle As Integer, ByRef et99sn As Byte) As Integer
	
	Declare Function et_HMAC_MD5 Lib "FT_ET99_API.dll" (ByVal et99handle As Integer, ByVal et99keyID As Integer, ByVal et99textLen As Short, ByRef et99pucText As Byte, ByRef et99pucDigest As Byte) As Integer
	
	Declare Function MD5_HMAC Lib "FT_ET99_API.dll" (ByRef et99pucText As Byte, ByVal et99textLen As Integer, ByRef et99pucKey As Byte, ByVal et99keyLen As Integer, ByRef et99tokenKey As Byte, ByRef et99pucDigest As Byte) As Integer
	
	Declare Function et_SetKey Lib "FT_ET99_API.dll" (ByVal et99handle As Integer, ByVal et99keyID As Integer, ByRef et99write As Byte) As Integer
	
	
	
	
	'UPGRADE_NOTE: str was upgraded to str_Renamed. Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A9E4979A-37FA-4718-9994-97DD76ED70A7"'
	Public Sub HexToString(ByRef ByteArray() As Byte, ByRef str_Renamed As String, ByRef lSize As Integer)
		Dim b As Byte
		Dim i As Integer
		
		For i = lSize - 1 To 0 Step -1
			b = ByteArray(i) \ 16
			If b > 9 Then
				str_Renamed = str_Renamed & Chr(b + Asc("A") - 10)
			Else
				str_Renamed = str_Renamed & Chr(b + Asc("0"))
			End If
			
			b = ByteArray(i) Mod 16
			If b > 9 Then
				str_Renamed = str_Renamed & Chr(b + Asc("A") - 10)
			Else
				str_Renamed = str_Renamed & Chr(b + Asc("0"))
			End If
		Next i
	End Sub
End Module