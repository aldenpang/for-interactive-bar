Option Strict Off
Option Explicit On
Friend Class Form1
	Inherits System.Windows.Forms.Form
	Dim retcode As Integer
	Dim et99pid As String
	Dim et99pin As String
	Dim et99count As Short
	Dim et99handle As Integer
	Dim curline As Short
	
	
	Private Sub Command1_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command1.Click
		
		If (Text1.Text = "") Then
			MsgBox("������PID")
			Exit Sub
		End If
		
		If (Text2.Text = "") Then
			MsgBox("������User PIN")
			Exit Sub
		End If
		
		curline = 0
		List1.Items.Clear()
		et99pid = Text1.Text
		
		retcode = et_FindToken(et99pid, et99count)
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "Find ET99 Failed. Please Check PID and UserPIN")
			Exit Sub
		Else
			VB6.SetItemString(List1, curline, "Find ET99 Success")
		End If
		
		Command2.Enabled = True
		
		
		
	End Sub
	
	Private Sub Command2_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command2.Click
		
		curline = curline + 1
		retcode = et_OpenToken(et99handle, et99pid, 1)
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "Open ET99 Failed. Please Check PID and UserPIN")
			Exit Sub
		Else
			VB6.SetItemString(List1, curline, "Open ET99 Success")
		End If
		
		et99pin = Text2.Text
		curline = curline + 1
		
		retcode = et_Verify(et99handle, 0, et99pin)
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "Open ET99 Failed. Please Check PID and UserPIN")
			Exit Sub
		Else
			VB6.SetItemString(List1, curline, "Verify PIN Success")
		End If
		
		Command3.Enabled = True
		Command4.Enabled = True
		Command5.Enabled = True
		Command6.Enabled = True
		Command7.Enabled = True
		Command8.Enabled = True
		Command9.Enabled = True
		
		
	End Sub
	
	Private Sub Command3_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command3.Click
		
		curline = curline + 1
		retcode = et_CloseToken(et99handle)
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "Close ET99 Failed")
		Else
			VB6.SetItemString(List1, curline, "Close ET99 Success")
		End If
		
		Command2.Enabled = False
		Command3.Enabled = False
		Command4.Enabled = False
		Command5.Enabled = False
		Command6.Enabled = False
		Command7.Enabled = False
		Command8.Enabled = False
		Command9.Enabled = False
		
		
    End Sub

    Private Function ByteArrayToString(ByVal ByteArray As System.Array) As String
        'Dim s As String = System.Text.Encoding.Default.GetString(ByteArray) 
        Dim strOut As String = ""
        For i As Integer = 0 To ByteArray.Length - 1
            If Not CType(ByteArray(i), Byte).ToString = 0 Then
                strOut &= System.Text.Encoding.Default.GetString(ByteArray, i, 1)
            End If
        Next
        Return strOut
    End Function


	
	Private Sub Command4_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command4.Click
		
		curline = curline + 1
		Dim writestr As String
        Dim writearr() As Byte

        Dim writestr1 As Integer

		
        writestr = "hello"

        'temp = System.Text.Encoding.Default.GetBytes(strtexts)
        'temp = System.Text.Encoding.ASCII.GetBytes(strtexts)
        'temp = System.Text.Encoding.Unicode.GetBytes(strtexts)
        'temp = System.Text.Encoding.UTF8.GetBytes(strtexts)

        writearr = System.Text.Encoding.Default.GetBytes(writestr)

        retcode = et_Write(et99handle, 0, Len(writestr), writearr(0))
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "et_Write Failed")
		Else
			VB6.SetItemString(List1, curline, "et_Write " & writestr & " Success")
		End If
		
	End Sub
	
	Private Sub Command5_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command5.Click
		
		curline = curline + 1
		Dim readarr(10) As Byte
		Dim readstr As String
		
		retcode = et_Read(et99handle, 0, 5, readarr(0))
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "et_Read Failed")
		Else
			VB6.SetItemString(List1, curline, "et_Read Success")
        End If

        readstr = ByteArrayToString(readarr)

		curline = curline + 1
		VB6.SetItemString(List1, curline, "Data: " & readstr)
		
	End Sub
	
	Private Sub Command6_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command6.Click
		
		curline = curline + 1
		Dim et99sn(8) As Byte
		Dim st99snstr As String
		
		retcode = et_GetSN(et99handle, et99sn(0))
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "et_GetSN Failed")
		Else
			VB6.SetItemString(List1, curline, "et_GetSN Success")
		End If
		
		HexToString(et99sn, st99snstr, 8)
		
		curline = curline + 1
		VB6.SetItemString(List1, curline, "SN: " & st99snstr)
		
	End Sub
	
	Private Sub Command7_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command7.Click
		If (Text4.Text = "") Then
			MsgBox("�����������")
			Exit Sub
		End If
		
		curline = curline + 1
		
		Dim sk As String
		Dim PucDigestArr2() As Byte
		Dim skArr() As Byte
		Dim strRe As String
		
		Dim keyID As Integer
		
		sk = Text4.Text '�������
        keyID = 1

        skArr = System.Text.Encoding.Default.GetBytes(sk)
        PucDigestArr2 = System.Text.Encoding.Default.GetBytes(Space(32))
		
    
		retcode = et_HMAC_MD5(et99handle, keyID, Len(sk), skArr(0), PucDigestArr2(0)) 'ʹ��indexΪ1����Կ
		
		HexToString(PucDigestArr2, strRe, 16)
		
		'result = StrConv��PucDigestArr2, vbUnicode)
		VB6.SetItemString(List1, curline, "Ӳ�����㣺" & strRe)
		
	End Sub
	
	Private Sub Command8_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command8.Click
		
		curline = curline + 1
		
		If (Text4.Text = "") Then
			MsgBox("�����������")
			Exit Sub
		End If
		
		If (Text5.Text = "") Then
			MsgBox("������Ҫ��֤����Կ")
			Exit Sub
		End If
		
		
		Dim sk As String
		Dim skArr() As Byte
		
		Dim strKey As String
		Dim arrKey() As Byte
		
		Dim PucDigestArr2() As Byte
		Dim result As String
		
		Dim tokenResult(32) As Byte '������û��
		
		sk = Text4.Text '�������16��1
		strKey = Text5.Text '������֤����Կ��������Ӧ�����ݿ��еõ�
	
        skArr = System.Text.Encoding.Default.GetBytes(sk)
        'skArr = System.Text.UnicodeEncoding.Unicode.GetBytes(StrConv(sk, vbFromUnicode))

   
        arrKey = System.Text.Encoding.Default.GetBytes(strKey)

        PucDigestArr2 = System.Text.Encoding.Default.GetBytes(Space(32))

		retcode = MD5_HMAC(skArr(0), Len(sk), arrKey(0), Len(strKey), tokenResult(0), PucDigestArr2(0))
		HexToString(PucDigestArr2, result, 16)
		
		VB6.SetItemString(List1, curline, "�������㣺" & result)
		
		
	End Sub
	
	Private Sub Command9_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles Command9.Click
		
		If (Text3.Text = "") Then
			MsgBox("��������Կ")
			Exit Sub
		End If
		
		curline = curline + 1
		
		Dim sk As String
		Dim skArr() As Byte
		
		Dim strKey As String
		Dim arrKey() As Byte
		
		Dim tokenResult(32) As Byte '32�ֽڵĽ��
		Dim PucDigestArr(16) As Byte '������û����
		
		Dim keyID As Integer
		
		sk = "1111111111111111"
	
        skArr = System.Text.Encoding.Default.GetBytes(sk)

		
		strKey = Text3.Text
	
        arrKey = System.Text.Encoding.Default.GetBytes(strKey)

		
		'�ȸ���SetKey���磺123456������32�ֽڵ���Կ
		retcode = MD5_HMAC(skArr(0), 16, arrKey(0), Len(strKey), tokenResult(0), PucDigestArr(0))
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "MD5_HMAC Failed.")
			Exit Sub
		Else
			VB6.SetItemString(List1, curline, "MD5_HMAC Success")
		End If
		
		'��32�ֽڵ���Կ����Ӳ��
		keyID = 1
		retcode = et_SetKey(et99handle, keyID, tokenResult(0))
		If (retcode <> 0) Then
			VB6.SetItemString(List1, curline, "et_SetKey Failed.")
			Exit Sub
		Else
			VB6.SetItemString(List1, curline, "et_SetKey Success")
		End If
		
	End Sub
End Class