/*====================================================================
  
	Purpose:Sample console editor for ET99 	
======================================================================*/

#if !defined(AFX_STDAFX_H__0433F148_F162_49CC_8F67_08BF3333003E__INCLUDED_)
#define AFX_STDAFX_H__0433F148_F162_49CC_8F67_08BF3333003E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include <ctype.h>

// TODO: reference additional headers your program requires here

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__0433F148_F162_49CC_8F67_08BF3333003E__INCLUDED_)
