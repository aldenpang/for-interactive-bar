// ET99StartServer.h : main header file for the ET99STARTSERVER application
//

#if !defined(AFX_ET99STARTSERVER_H__E4B5ED3C_1AFA_449A_B6E7_E3D12B89A7B8__INCLUDED_)
#define AFX_ET99STARTSERVER_H__E4B5ED3C_1AFA_449A_B6E7_E3D12B89A7B8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CET99StartServerApp:
// See ET99StartServer.cpp for the implementation of this class
//

class CET99StartServerApp : public CWinApp
{
public:
	CET99StartServerApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CET99StartServerApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CET99StartServerApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ET99STARTSERVER_H__E4B5ED3C_1AFA_449A_B6E7_E3D12B89A7B8__INCLUDED_)
