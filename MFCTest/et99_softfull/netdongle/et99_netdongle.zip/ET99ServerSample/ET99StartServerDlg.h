// ET99StartServerDlg.h : header file
//

#if !defined(AFX_ET99STARTSERVERDLG_H__84ABB33C_319D_442F_849F_1E64207B54C0__INCLUDED_)
#define AFX_ET99STARTSERVERDLG_H__84ABB33C_319D_442F_849F_1E64207B54C0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CET99StartServerDlg dialog

class CET99StartServerDlg : public CDialog
{
// Construction
public:
	CET99StartServerDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CET99StartServerDlg)
	enum { IDD = IDD_ET99STARTSERVER_DIALOG };
	CString	m_strPID;
	CString	m_strUserPIN;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CET99StartServerDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CET99StartServerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ET99STARTSERVERDLG_H__84ABB33C_319D_442F_849F_1E64207B54C0__INCLUDED_)
