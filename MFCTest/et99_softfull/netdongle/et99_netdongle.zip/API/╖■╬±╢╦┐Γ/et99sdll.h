#ifdef __cplusplus
	extern "C"{
#endif

DWORD WINAPI ETStartServer(char *pid, char *userpin);
//����0�ɹ�
void WINAPI ETStopServer();
DWORD WINAPI ETGetMaxUsers();
DWORD WINAPI ETGetCurrentUsers();

#ifdef __cplusplus
	}
#endif